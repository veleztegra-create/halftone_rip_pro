# Changelog

Registro de cambios de implementación (bugfixes, performance, seguridad). A diferencia de
`docs/ADR/`, esto no son decisiones de arquitectura — son correcciones puntuales. Ver
`docs/ADR/ADR-010.md` para el protocolo que originó la investigación de abajo.

---

## [0.4.6] — 2026-07-20 — Mensaje de overprint, confirmado con job real (blippiymika)

```
MEJORA — Comunicación
Mensaje humano del hallazgo "overprint no deseado"
No architectural impact. Solo texto — no cambia el umbral ni la detección.
```

**Contexto:** job real (`blippiymika`, 10 separaciones, build 0.4.5) reportó
`MORADO - Posible overprint no deseado, 16%`. Isaac confirmó con la prueba/mockup real
(imagen con marcas de corte y barra de color) que el overprint es intencional — el fondo
morado del diseño se construye superponiendo puntos de trama de azul y naranja, una técnica
normal de mezcla de color en separación de tramas. Mismo job: confirmó también que el
blanco de refuerzo (ver v0.4.3, ADR-013) es prácticamente universal en trabajos con
tramas/semitonos, no un caso ocasional.

**Decisión (mismo criterio que Frente 2/ADR-013):** no se toca la detección — el finding
sigue disparando con el mismo umbral (`false_ink > 10`) y sigue siendo `status: warn`
("REVISAR", no se suprime). Solo se enriqueció el mensaje humano para explicar CUÁNDO el
overprint suele ser intencional (mezcla de color vía tramas superpuestas) y sugerir
comparar contra la prueba/mockup — mismo patrón ya usado en el hallazgo de tinta de más
(v0.4.5).

**Verification:**
- ✓ Verified — sintaxis, boot, regresión completa de las suites existentes.
- ⚠ Assumed — el texto nuevo asume que "mezcla de color por tramas superpuestas" es la
  explicación más común de overprint intencional en este taller; no cubre otras razones
  legítimas de overprint que puedan existir. Es un mensaje orientativo, no exhaustivo.

**Nota para v1.1/Producto:** con 3 de 3 jobs reales mostrando el mismo canal blanco de
aclarado, está claro que el campo "Palabras clave refuerzo extra" se re-escribe en cada
trabajo. Se propuso (no implementado todavía, pendiente confirmación) recordar el último
valor usado en el navegador (localStorage), sin cambiar que sea una decisión explícita del
usuario — no detección automática.

---

## [0.4.5] — 2026-07-20 — Beta Credibilidad, Frente 1/2/4 (comunicación + layout)

```
MEJORA — UX/Comunicación
Lenguaje humano en reportes + leyenda de colores + layout del comparador
No architectural impact. No toca score, status, ni pct de ningún finding.
```

### 1. Leyenda de colores del mapa de diferencias

**Síntoma:** el único color explicado era rojo ("Rojo = Alta Diferencia"), y esa
descripción era imprecisa. Azul (el color más visible en casos como el reportado —
ver Frente 2 más abajo en este documento) no se explicaba en ningún lado.

**Corrección:** leyenda de 3 colores junto al mapa de diferencias, con los nombres
correctos según `app.py:1085-1087` (verde=coincide, rojo=falta, azul=de más).

### 2. Mensajes de hallazgos en lenguaje humano

**Síntoma:** mensajes como `"Se detectaron cambios estructurales importantes: IoU 0.070,
recall 0.991."` — técnicamente correctos, ilegibles para un cliente final, que los lee
como "esto es un bug" en vez de "esto es una diferencia real de la separación".

**Corrección:** cada finding (`build_structural_findings()` y los 3 findings por canal en
`/api/analyze_detailed`) ahora incluye un campo `human` (lenguaje claro) además de `msg`
(sin tocar — sigue igual, técnico). El frontend muestra `human` como texto principal y
`msg` colapsado bajo "Detalles técnicos ▼". Es puramente aditivo: `status`/`pct`/`score`
no cambian, cero impacto en el algoritmo.

**Detalle relevante:** para hallazgos de "Información adicional" grandes (≥5% del canvas),
el mensaje humano ahora sugiere explícitamente revisar si la placa es una tinta de
refuerzo/aclarado y apunta al campo "Palabras clave refuerzo extra" — conectando
directamente con el mecanismo que ya existía (ver v0.4.3). Bloques chicos no reciben esta
sugerencia (umbral verificado con test, no aplica a todo por igual).

### 3. `#align-container` crecía sin límite con referencias muy altas

**Síntoma reportado:** "es necesario estar bajando y subiendo la barra" para alternar entre
ver la imagen de comparación y ver los resultados del análisis.

**Causa raíz:** el contenedor de comparación no tenía límite de altura; con una referencia
en formato retrato (común en trabajos de serigrafía, ej. 7150×10750), la imagen a
`width:100%` de una columna de la mitad de la página se renderiza extremadamente alta,
empujando `#diff-results` (los hallazgos) muy por debajo del viewport.

**Corrección:** `max-height: 65vh; overflow-y: auto;` en `#align-container` (antes
`overflow: hidden` sin límite de altura). La imagen sigue viéndose completa — con scroll
propio dentro de esa caja — en vez de expandir toda la página.

**Verification:**
- ✓ Verified — `positionHandles()` usa `container.clientWidth` y posicionamiento absoluto,
  no depende de la altura ni del scroll del contenedor — confirmado por lectura de código
  antes de aplicar el cambio, no asumido.
- ✓ Verified — con navegador real (Playwright) y una imagen de referencia muy alta: el
  contenedor renderizado queda en 585px (65% de un viewport de 900px) en vez de crecer a
  ~2999px sin límite. `#diff-results` queda ~2400px más arriba que antes.
- ✓ Verified — regresión: `tests/test_reference_center_drag_e2e.py` (arrastre desde el
  centro) sigue pasando con el nuevo `overflow-y: auto` — no se rompió nada de lo corregido
  en v0.4.4.
- ⚠ Assumed — `65vh` es un valor de partida razonable, no calibrado contra pantallas reales
  de GraphXSource. Es un solo número en `templates/index.html` si hace falta ajustar.

**Pendiente, no resuelto en esta entrega:** zoom con rueda del mouse y pan más fluido
(Beta Polish Backlog #2) — esto resuelve el caso más grave (crecimiento sin límite), no
toda la navegación del visor.

---

## [0.4.4] — 2026-07-19 — Arrastre de referencia desde el centro (bug real, no feature nueva)

```
BUGFIX — UI
Arrastre de la referencia bloqueado por pointer-events inline
No architectural impact.
```

### El control de alineación "solo funcionaba en las esquinas"

**Síntoma reportado:** solo era posible reposicionar la imagen de referencia usando las 4
manijas de las esquinas (que escalan). Arrastrar desde el centro de la imagen (que debería
mover sin escalar) no hacía nada.

**Causa raíz:** `<img id="ref-preview-img">` tenía `pointer-events: none;` puesto **inline**
en `templates/index.html`. El código para arrastre desde el centro (`startBodyDrag()`,
enganchado vía `refImg.onpointerdown`) ya existía en `preview.js`, y la regla CSS que debía
habilitarlo (`.diff-overlay.align-editable { pointer-events: auto; }`) también ya existía
en `styles.css` — pero un estilo inline en HTML siempre gana en especificidad sobre una
regla de clase en una hoja de estilos externa (sin `!important`), así que el JS nunca
recibía el evento. Las manijas de esquina sí funcionaban porque son elementos `<div>`
separados, sin ese estilo inline.

**Corrección:** se quitó el `pointer-events: none;` inline. El comportamiento por defecto
(sin arrastre, cuando no hay clase `align-editable`) se mantiene exactamente igual, porque
`.diff-overlay { pointer-events: none; }` ya lo cubre en la hoja de estilos externa — el
inline era puramente redundante en el estado default, y activamente dañino en el estado
editable.

**Verification:**
- ✓ Verified — estado default: `pointer-events` sigue siendo `none` sin la clase
  `align-editable` (cero cambio de comportamiento fuera del modo de edición).
- ✓ Verified — estado editable: `pointer-events` pasa a `auto`, y `elementFromPoint()` en
  el centro de la imagen devuelve `ref-preview-img` (antes devolvía lo que estuviera
  detrás — confirmado con navegador real, Playwright + Chromium, no inspección de código
  sola).
- ✓ Verified — arrastre end-to-end completo: disparando el flujo real de la app
  (`<input type="file">` real → `loadRefFile` → `loadRefImage` → `initAlignHandles`, sin
  atajos), un arrastre de mouse de `(+60, +40)` px movió `align-x`/`align-y` de `0, 0` a
  `60, 40` exactamente.
- ⚠ Assumed — no se pudo probar el flujo 100% real de punta a punta (subir PDF → procesar
  con Ghostscript → cargar referencia → arrastrar) porque este sandbox no tiene Ghostscript
  instalado. Se compensó cargando manualmente una imagen de fondo sintética en
  `#align-base-img` (que en producción la llena `loadSeparationBase()` tras procesar un
  job real) — todo lo demás en la prueba usó el mecanismo genuino de la app.

---

## [0.4.3] — 2026-07-19 — Beta Credibilidad, Frente 2 (A.1)

```
BUGFIX — Paridad bilingüe
is_reinforcement_channel_name()
Corrección de Beta según ADR-013 (4 condiciones cumplidas), NO el Production-Aware Engine.
```

### Falso positivo estructural cuando blanco se usa como aclarador óptico

**Contexto:** investigación completa en `docs/PRODUCTION_AWARE_COMPARE_VISION.md` y
`docs/SPRINT_BETA_CREDIBILIDAD_BACKLOG.md` (Frente 2). Causa raíz:
`light_through *= (1.0 - ink)` trata todo canal como absorbente; un canal de blanco usado
como aclarador óptico (técnica real de serigrafía) es reflectivo, no absorbente — genera
falso "extra" cuando se compara contra la referencia.

**Decisión de alcance (ADR-013):** NO se modifica el modelo de composición (`light_through`)
ni se agrega interpretación de técnicas de impresión — eso es V2
(`docs/PRODUCTION_AWARE_COMPARE_VISION.md`). Se corrige únicamente una asimetría bilingüe
real en el mecanismo de exclusión YA EXISTENTE (`is_reinforcement_channel_name()`):
`'refuerzo'` no tenía su equivalente en inglés `'reinforcement'`, y `'highlight blanco'`
no tenía `'highlight white'`.

**Hallazgo adicional (sin cambio de código):** el mecanismo para excluir un canal
específico por nombre, per-job, ya existe end-to-end — input `reinforcement-keywords` en
la UI (`templates/index.html:451`) → `preview.js:1053` lo envía → `app.py` lo recibe como
`extra_keywords`. Un usuario con este caso puede resolverlo hoy mismo escribiendo el
nombre real de su canal blanco/aclarador en ese campo, sin esperar ningún release.

**Verification:**
- ✓ Verified — equivalencia exacta: 8 nombres que ya se excluían (`BASE`, `Refuerzo`,
  `UNDERBASE`, `Highlight Blanco`, etc.) siguen excluyéndose idénticamente
  (`tests/test_reinforcement_channel_detection.py`, TEST 1).
- ✓ Verified — nueva cobertura: `Reinforcement`, `Highlight White` (y variantes de
  mayúsculas) ahora se excluyen por defecto, cerrando el gap bilingüe (TEST 2).
- ✓ Verified — guarda de seguridad: `Blanco`, `White`, `BLANCO` sueltos **siguen sin
  excluirse por defecto** — no se debilitó la cautela original del diseño (TEST 3).
- ✓ Verified — el mecanismo per-job (`extra_keywords`) resuelve el caso real
  (`'BLANCO ACLARADOR'` con keyword de usuario `'blanco aclarador'` → excluido
  correctamente) (TEST 4).
- ✓ Verified — cumple las 4 condiciones de ADR-013 (evidencia, causa raíz, corrección
  localizada, sin modelo mental nuevo) — tabla completa en `docs/ADR/ADR-013.md`.

---

## [0.4.2] — 2026-07-18 — Beta Polish, Tarea 3.2

```
BUGFIX + Punto de sustitución
Display Color Resolver
No architectural impact — respeta el freeze.
```

### `get_color_for_separation()` asignaba color plano ignorando modificadores tonales

**Síntoma reportado:** la placa `"AZUL OSCURO"` se mostraba en el visor como `#1e90ff`
(azul brillante/DodgerBlue), no como un azul oscuro.

**Protocolo de Diagnóstico aplicado (ADR-010):** se confirmó primero que este color NO pasa
por `core/knowledge/` (el Knowledge Engine JS) — es asignado por el backend Python en
`get_color_for_separation()`, un sistema de color completamente separado y preexistente que
nadie había comparado contra el Knowledge Engine hasta ahora.

**Causa raíz:** `color_map` hacía `if 'azul' in name_lower: return (30, 144, 255)` — un
match por substring que ignora cualquier modificador ("oscuro", "claro", "muy oscuro") en
el resto del nombre. Esto es un segundo diccionario de color, duplicado e independiente del
Knowledge Engine, sin ningún concepto de modificador.

**Decisión de diseño (no solo bugfix):** en vez de agregar entradas explícitas
(`"azul oscuro"`, `"azul claro"`, ...) al diccionario — lo cual escala mal (se estimó del
orden de 180 `if` en pocas semanas) — se implementó una transformación: color base +
ajuste de Lightness en espacio HSL, con una tabla `MODIFIERS` centralizada (`light: +20`,
`dark: -20`, `deep: -30`, etc.) en vez de números mágicos repetidos. Colores con identidad
propia en la industria textil (`navy`, `royal blue`, `kelly green`, `forest green`,
`burgundy`, `maroon`) se excluyen de la transformación — no son "azul oscuro", son tonos
con nombre propio, y se resuelven antes de intentar cualquier detección de modificador.

**Punto de sustitución:** la lógica se extrajo de `app.py` a
`backend/color_name_resolver.py` (`resolve_display_color()`). `app.py` mantiene
`get_color_for_separation()` como wrapper delgado (3 call sites existentes, no tocados)
que delega al resolver. Cuando exista un Knowledge Interpreter real en el backend (v1.1),
solo cambia el cuerpo de `resolve_display_color()` — ningún otro archivo necesita tocarse.
Esto es preparar el terreno, no construir el Interpreter ahora — no hay IA, no hay
tokenizer, no se tocó `core/knowledge/`, no se movieron contratos.

**Nota de alcance importante:** este color es de **visualización**, no un valor de
producción — ayuda al usuario a distinguir placas en pantalla, no reemplaza un Pantone.
Esa es la razón por la que un ajuste de Lightness en HSL (no colorimétricamente exacto) es
aceptable acá.

**Verification:**
- ✓ Verified — equivalencia exacta con el comportamiento anterior para 31 casos sin
  modificador (`tests/test_color_name_resolver.py`, TEST 1), incluyendo el caso base
  `"AZUL"` reportado junto con el bug, que debía seguir siendo `#1e90ff` sin cambios.
- ✓ Verified — el caso reportado (`"AZUL OSCURO"`) ya no es `#1e90ff`; ahora es `#005db7`,
  con suma RGB menor que el azul base (TEST 2).
- ✓ Verified — dirección de luminosidad correcta en 11 combinaciones ES/EN de modificador +
  color base (TEST 3), y orden monotónico `azul > azul oscuro > azul muy oscuro` (TEST 4).
- ✓ Verified — colores con identidad propia (`navy`, `royal blue`, `kelly green`) no
  colapsan a "color base + modificador" (TEST 5).
- ⚠ Assumed — los valores de la tabla `MODIFIERS` (±20/±30/etc.) son un punto de partida
  razonable, no calibrados contra percepción real de usuarios de GraphXSource. Si algún
  tono queda "demasiado oscuro/claro" en la práctica, se ajusta un solo número en
  `backend/color_name_resolver.py`, no hay que tocar `app.py` ni ningún call site.

**Addendum (mismo día, revisión de Atlas):** los valores de `MODIFIERS` se reexpresaron
como `LIGHTNESS_STEP` + derivados (`LIGHTNESS_STEP_DEEP`, `_SUBTLE`, `_BRIGHT`) en vez de
números sueltos — refactor puro, verificado que los valores numéricos resultantes son
idénticos, cero cambio de comportamiento. Además se formalizó **ADR-012**
(`docs/ADR/ADR-012.md`): toda lógica de interpretación de nombres vive en un único lugar
del sistema — `resolve_display_color()` se documenta explícitamente como una excepción
temporal reconocida a esa regla, no como el estado final.

---

## [Sin versión de producto — parche durante ARCHITECTURE FREEZE] — 2026-07-15

```
BUGFIX
Performance
No architectural impact.
Approved during Freeze.
```

### `connected_components_summary()` — O(count × pixels) → O(pixels)

**Síntoma reportado:** `/api/analyze_detailed` se quedaba en "Analizando..." de forma
indefinida sobre un trabajo de 7150×10750px / 7 canales.

**Protocolo de Diagnóstico aplicado (ADR-010):** confirmado vía logs que el request
terminaba con `200` (no crasheaba) después de **~61-62 minutos** — no era un hang, era
cómputo real, pero patológicamente lento.

**Causa raíz:** el loop `for label in range(1, count+1): np.where(labeled == label)`
comparaba el array completo (≈77M elementos) por cada componente conectado. Con una máscara
de halftone (miles de puntos de trama = miles de componentes diminutos), esto es
O(componentes × píxeles) — en este caso, del orden de 10⁴ componentes × 7.7×10⁷ píxeles.

**Corrección:** reemplazado por `scipy.ndimage.find_objects()`, que devuelve el bounding
box de cada componente en una sola pasada vectorizada — O(píxeles) total. `bbox` se toma
directo del slice (matemáticamente idéntico al `xs.min()`/`xs.max()+1` anterior, por
definición de `find_objects`); `area` y `centroid` se recalculan sobre el slice recortado
(no sobre el bbox completo), porque bboxes de componentes distintos pueden solaparse sin que
los componentes se toquen.

**Verificación de equivalencia semántica:** comparación directa OLD vs NEW sobre máscaras
sintéticas tipo halftone (incluyendo casos con bboxes solapados), con `min_area` variable y
casos borde (máscara vacía, todo filtrado). Área/bbox/centroide idénticos componente por
componente en todos los casos.

**Verification:**
- ✓ Verified — equivalencia semántica (área/bbox/centroide, casos borde, bboxes solapados)
- ✓ Verified — mejora de performance (medida, no estimada)
- ⚠ Assumed — impacto en jobs de producción a resolución completa (pendiente de validación real; ver "Observed production impact" abajo)

**Measured benchmark** (dataset representativo — 1200×1200px, ~10.750 componentes reales,
NO el tamaño real de producción):

```
36.2 s → 0.19 s
(189x en dataset representativo)
```

**Observed production impact:**

```
Se espera una reducción drástica del tiempo de ejecución.
Pendiente de validación en trabajos de resolución completa de producción.
```

(Nota: una versión anterior de esta entrada incluía una extrapolación numérica a
7150×10750px. Se removió a propósito — una extrapolación nunca deja de ser una estimación,
y no corresponde presentarla con el mismo peso que una medición real. El 189x de arriba SÍ
es una medición real; lo que no está medido todavía es el impacto sobre un job de
producción a resolución completa.)

**Instrumentación agregada (mínima, no un módulo nuevo):** `[PERF] connected_components_summary: X.XXXs (N componentes, M >= min_area)` impreso en cada llamada, para que el próximo
`/api/analyze_detailed` lento se pueda diagnosticar en segundos vía el mismo protocolo,
en vez de otra ronda de logs a ciegas.
