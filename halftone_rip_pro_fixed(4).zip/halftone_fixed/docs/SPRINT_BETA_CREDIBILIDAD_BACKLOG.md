# Sprint Beta — Credibilidad

**Estado:** Propuesta — pendiente de aprobación
**Objetivo:** que un usuario abra un reporte y piense "esto coincide con lo que estoy
viendo", no que dude del número.
**Regla de trabajo (heredada de Beta Polish):** no se toca nada que no esté en esta tabla.
**Relación con freeze:** todo esto es comunicación/presentación sobre datos que el backend
ya calcula. No toca `core/knowledge/`, no toca contratos, no rompe ADR-006.

---

## Corrección de partida (verificado, no asumido)

El Frente 1 original proponía relabelear `"Diferencia promedio"` → `"Coincidencia"`
**manteniendo el mismo número**. Se verificó contra el código real
(`app.py:1113-1118`, `preview.js:1088-1105`): `score` es un **penalty acumulado** (0 =
perfecto, 100 = muy diferente) — `missing_penalty + extra_penalty + iou_penalty +
component_penalty`. El label actual (`"Diferencia promedio"`) ya es semánticamente
correcto para ese número.

**Si se relabelea a `"Coincidencia"` sin invertir el número, el reporte pasa a decir "97%
coincide" cuando en realidad hay un 97% de penalty** — el resultado sería más engañoso que
el estado actual, no menos. La corrección real es `coincidencia = 100 - score` (una línea
en `preview.js`), no un cambio de texto. Se refleja en la tabla como ítem propio, marcado
como "requiere cálculo, no solo texto" para que nadie lo shippee como find-and-replace.

---

## Tabla

| # | Frente | Problema | Impacto | Complejidad | Nota |
|---|--------|----------|---------|-------------|------|
| 1 | Lenguaje | `score` (penalty) se muestra como `"Diferencia promedio"` — correcto hoy, pero si se quiere mostrar como "Coincidencia/Similitud" **hay que invertir el número**, no solo el texto | Muy alto | Bajo | Ver corrección arriba. Una línea de cálculo + el relabel. |
| 1 | Lenguaje | `score` (penalty) se muestra como `"Diferencia promedio"` — correcto hoy, pero si se quiere mostrar como "Coincidencia/Similitud" **hay que invertir el número**, no solo el texto | Muy alto | Bajo | Ver corrección arriba. Una línea de cálculo + el relabel. **Pendiente — no implementado todavía, esperando confirmación explícita de la inversión de número.** |
| 2 | Severidad + Lenguaje | Reportes no distinguen crítico/importante/menor, y usan jerga (`IoU 0.070`) | Alto | Bajo | **Hecho (v0.4.5).** Cada finding ahora tiene un campo `human` (lenguaje claro) además de `msg` (técnico, colapsable bajo "Detalles técnicos"). Ver `docs/CHANGELOG.md`. |
| 3 | Confianza visual | `"24945208 px"` sin contexto | Alto | Bajo | **Hecho (v0.4.5).** El mensaje humano formatea el número (`24.847.559 px`) y, para bloques grandes (≥5% del canvas), sugiere revisar si es una placa de refuerzo/aclarado — conectando directo con el campo "Palabras clave refuerzo extra". |
| 4 | Explicación técnica | `IoU 0.069` sin traducción | Alto | Medio | Requiere texto interpretativo nuevo por rango de métrica (no solo mostrar/ocultar) — más que un `<details>`, hay que decidir qué frase corresponde a qué combinación de `iou`/`recall`/`missing_pct`. |
| 5 | Mapa de diferencias | Todo se ve "rojo total", sin filtros por tipo | Medio-Alto | Medio | Filtrar el diff map por categoría (`geometría`/`overprint`/`ruido`) requiere que esas categorías existan como capas separables en el mapa, no solo en el listado de findings — a confirmar si el diff map actual ya separa esa información o hay que generarla aparte. |
| 6 | Navegación del visor | Ya identificado en Beta Polish (zoom/pan) | Muy alto | Medio | Mismo ítem que `docs/BETA_POLISH_BACKLOG.md` #2. **Parcial (v0.4.5):** se corrigió el caso más grave — `#align-container` crecía sin límite con referencias muy altas, empujando los resultados fuera de vista y forzando scroll de página completa. Ahora tiene altura acotada (65vh) con scroll interno propio. Zoom con rueda / pan más fluido siguen pendientes. |
| 7 | **Frente 2 — modelo de composición no representa blanco de aclarado** | `IoU` bajo por falso "extra" cuando blanco se usa para aclarar ópticamente otro color (no es ruido ni error de producción) | Alto | Bajo-Medio (Opción A) | Causa raíz confirmada: `light_through *= (1-ink)` trata todo canal como absorbente; blanco de aclarado es reflectivo. Ver sección siguiente para las dos opciones de corrección. |

---

## Frente 2, tratado aparte: ¿qué está pasando con `IoU 0.069`?

**Corrección sobre la conclusión anterior — el compuesto reconstruido tiene un supuesto
incorrecto, confirmado por dominio + código.** Isaac aportó un dato de serigrafía que la
medición de píxeles sola no podía revelar: en impresión textil, aclarar un color oscuro
(ej. azul) no se hace bajando su opacidad — se hace imprimiendo una **trama de blanco
encima**, que aclara ópticamente por reflexión. Revisando cómo se arma `combined_sep_arr`
para la comparación (`app.py`, alrededor de la línea 2159):

```
light_through *= (1.0 - ink)   # para cada canal NO marcado como refuerzo
```

Este modelo trata **toda** tinta como absorbente/translúcida (correcto para tintas de
proceso tipo CMYK, que se acumulan oscureciendo). Es incorrecto para blanco usado como
aclarador óptico, que hace lo contrario. Resultado: en la zona donde azul + trama de
blanco deberían verse claras, el compuesto reconstruido las acumula como si oscurecieran
→ sale oscura → se compara contra una referencia que ahí es clara → **se mide como "extra"
falso**, exactamente los 24.9M px medidos.

`is_reinforcement_channel_name()` ya excluye canales tipo underbase de esta acumulación
por la misma razón general (no deben contarse como "tinta visible" al comparar), pero
documenta explícitamente que NO incluye "blanco" a secas por defecto — con razón, un canal
blanco a veces es contenido visible real (texto blanco), no técnica de aclarado. Este job
es el caso que esa exclusión, tal como está, no cubre.

**Esto es un hallazgo de algoritmo, no de comunicación — corrige lo que dije en la versión
anterior de esta sección.** El 71.8% no es (solo) un problema de que el reporte no destacó
bien un hallazgo correcto; una parte real de esa cifra es un falso positivo del modelo de
composición. Se necesita una decisión de arquitectura antes de tocar código (ADR-011 exige
equivalencia + mejora demostrada, y esto modifica el algoritmo de comparación estructural,
no solo texto de UI):

- **Opción A — extender el mecanismo existente:** permitir marcar un canal blanco
  específico como "aclarador" (mismo patrón que `reinforcement_keywords`, configurable por
  trabajo ya que no todo blanco es aclarador), y excluirlo de `light_through` igual que a
  un canal de refuerzo. Barato, reutiliza arquitectura ya aprobada, no intenta modelar
  óptica de reflexión real.
- **Opción B — modelar la reflexión real:** cambiar la fórmula para que blanco reduzca
  `light_through` acumulado en vez de multiplicarlo por más tinta. Más correcto
  físicamente, más caro, mayor riesgo de romper otros jobs que sí usan blanco como
  contenido visible normal.

**Decisión del arquitecto:** ninguna de las dos opciones se implementa como parche ahora.
El patrón se repite en más casos de los que parecía (underbase, discharge, highlight
white, metallic — ver `docs/PRODUCTION_AWARE_COMPARE_VISION.md`), y resolverlo caso por
caso reproduciría el problema que ADR-012 ya identificó (excepciones ad-hoc en vez de
causa raíz). Se documentó como visión de v2 (`docs/PRODUCTION_AWARE_COMPARE_VISION.md`,
enlazado desde `docs/ROADMAP.md`).

**Decisión final (A.1, ver `docs/ADR/ADR-013.md`):** se corrigió una asimetría bilingüe
real en `is_reinforcement_channel_name()` — `'refuerzo'` no tenía `'reinforcement'`,
`'highlight blanco'` no tenía `'highlight white'`. Es una corrección de paridad, no una
heurística nueva; pasa las 4 condiciones de ADR-013. Además se confirmó (con test) que el
mecanismo per-job **ya existente y ya conectado a la UI** (`reinforcement-keywords`)
resuelve el caso real de este job hoy mismo, sin ningún cambio de código — el usuario solo
necesita escribir el nombre real del canal blanco/aclarador en ese campo. Ver
`docs/CHANGELOG.md` para el detalle y la verificación completa.

**Explícitamente NO se hizo:** agregar `'blanco'`/`'white'` sueltos a la lista de
exclusión por defecto — eso rompería la cautela original del diseño (un canal blanco
puede ser contenido visible real) y violaría la condición 4 de ADR-013 (introduciría una
heurística nueva, no corregiría un error demostrado). Verificado explícitamente con test
que esto NO ocurrió (`tests/test_reinforcement_channel_detection.py`, TEST 3).

**Sigue habiendo una pregunta genuina de Frente 2, más acotada que la original:** el 0.3%
de "missing" (rojo, `110,950 px` en la imagen medida, pero solo `15,632 px` corresponden a
los 3 hallazgos individuales reportados — el resto quedó por debajo del umbral de
componente individual) sí es candidato a ser el tipo de ruido/jitter sub-píxel que Frente 2
originalmente sospechaba. Es un contribuyente mucho más chico al score que el bloque
extra, pero si aparece consistentemente en otros jobs, ahí sí valdría la pena investigar
si el algoritmo de alineación podría reducirlo. No se investiga ahora — se anota para
cuando haya más de un caso real con el que comparar.

---

## Qué decisión falta (tuya, no mía)

1. ¿Confirmás la corrección del Frente 1 (invertir el número si se relabelea)?
2. ¿El Frente 2 se investiga como diagnóstico separado antes de este sprint, en paralelo, o
   se pospone a v1.1? Mi lectura: separado y primero, aunque sea corto — es la única pieza
   de este sprint que toca el algoritmo, no la comunicación, y por ADR-011 necesita su
   propia evidencia antes de aceptarse.
3. Ítems 2 y 3 de la tabla (severidad, barra de %) son los de mejor relación
   impacto/esfuerzo — candidatos naturales para arrancar primero si querés ver resultado
   rápido.
