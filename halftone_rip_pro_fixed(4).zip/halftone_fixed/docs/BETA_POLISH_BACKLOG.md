# Beta Polish Backlog

**Estado:** Propuesta — pendiente de aprobación
**Objetivo:** que GraphXSource, al cabo de los 15 días, diga "se siente profesional".
**Regla de trabajo:** no se toca nada que no esté en esta tabla.

---

## Corrección de partida (verificado, no asumido)

El ejemplo original de Frente 3 (`Dark Blue → Blue`, perdiendo el modificador) **se probó
contra el código actual y no ocurre**: `"Dark Blue"`, `"dark blue"` y `"Blue Dark"` ya
resuelven hoy a `#003E7A` (azul oscuro), no al azul base. Si se vio ese comportamiento, es
sobre una build vieja — confirmar con `/api/build_info`. Este ítem del backlog ya está
resuelto y no consume tiempo de sprint.

Donde sí hay un gap real: `"Metallic Gold 872C"` hoy resuelve solo `Gold` y descarta
`Metallic`/`872C` en silencio — el matcher para en la primera palabra reconocida, no
reconoce varias categorías en el mismo string. Cerrar esto (y las reglas de Frente 4, que
dependen del mismo mecanismo) requiere la primera versión real del Interpreter — no es
"conectar dos archivos", es el trabajo que el freeze pausó a propósito. Se refleja abajo en
Complejidad, no se descarta del backlog.

---

## Tabla

| # | Problema | Frente | Impacto | Complejidad | Nota |
|---|----------|--------|---------|-------------|------|
| 1 | Reportes de análisis usan jerga técnica sin interpretación (`IoU 0.499`, `14 115 264 px`) | Lenguaje | Muy alto | Bajo | Mismo algoritmo, solo mensaje. Backend ya calcula `iou`/`recall` (`app.py`) — es texto, no lógica nueva. |
| 2 | Scroll/zoom/pan incómodo en el comparador | UX | Muy alto | Medio | No toca el algoritmo de comparación, solo interacción del visor. |
| 3 | Estados de carga sin indicador de progreso (se siente "colgado") | UX | Alto | Bajo | Ya hay evidencia real de que esto importa — el caso del `analyze_detailed` sin feedback fue reportado como bug antes de confirmarse que era solo lento. |
| 4 | Reconocimiento de nombres de color simples (un solo color + modificador) | Confianza | Alto | **Resuelto (frontend + backend)** | Frontend (`core/knowledge/`) ya funcionaba. Auditoría posterior encontró que el **backend tenía un segundo motor de color independiente** (`get_color_for_separation()`) sin soporte de modificadores — causaba el bug real reportado (`"AZUL OSCURO"` → `#1e90ff`). Corregido en `backend/color_name_resolver.py`, ver `docs/CHANGELOG.md` v0.4.2. |
| 5 | Reconocimiento de nombres compuestos (`Metallic Gold 872C` con las 3 partes a la vez) | Confianza | Alto | **Alto — requiere Interpreter real** | Esto es Sprint C/D del roadmap (`docs/ROADMAP.md`), no polish. Decisión explícita abajo. |
| 6 | Reglas de advertencia simples (Metallic + Halftone → revisión sugerida) | Inteligencia | Medio-Alto | **Alto — depende de #5** | Necesita que el motor reconozca "Metallic" dentro de un string compuesto primero. No es una regla aislada. |
| 7 | Dashboard nuevo | — | Bajo | Alto | Fuera de beta, va a v2 — coincide con la propuesta original. |

---

## Decisión que falta tomar (no la tomo yo, es tuya)

Los ítems 1, 2, 3 y 4 son polish genuino: no rompen el freeze, no tocan `core/knowledge/`,
son bajo/medio esfuerzo con impacto alto. Se pueden arrancar ya.

Los ítems 5 y 6 son, en la práctica, **empezar el Interpreter** — el freeze existe
precisamente para no arrancar eso sin documento previo. Tres caminos, elegí uno:

- **(a)** Se dejan fuera de la beta. GraphXSource ve reconocimiento de colores simples
  (ítem 4, ya andando) pero no nombres compuestos. Cero riesgo arquitectónico.
- **(b)** Se abre una excepción puntual al freeze *solo* para un Interpreter mínimo (no el
  tokenizer completo del roadmap) que resuelva el caso compuesto más común
  (`Modifier + Qualifier + BaseColor`, sin Pantone ni Technique todavía). Alcance chico,
  medible, con el mismo criterio de ADR-011 (equivalencia + benchmark) aplicado a
  "coincide con lo que un humano esperaría", no a performance.
- **(c)** Se hace el Interpreter completo ahora, moviendo Sprint C/D del roadmap para
  antes de la beta en vez de después.

Mi lectura, con la evidencia que tengo: **(a)**. Los 15 días de GraphXSource se ganan más
con reportes legibles y un visor fluido (ítems 1-3, bajo riesgo) que con reconocimiento de
nombres compuestos — y meter Interpreter sin el diseño ya cerrado en
`docs/KNOWLEDGE_PIPELINE_SPEC_v1.0.md`/`KNOWLEDGE_INFO_SPEC_v1.0.md` totalmente resuelto
(quedan preguntas abiertas ahí, sección 6) es exactamente el riesgo que el freeze fue
pensado para evitar. Pero es tu decisión de producto, no la mía — lo dejo explícito en vez
de elegir por vos.
