# Production-Aware Comparison Engine — Visión v2

**Estado:** Documentado, no diseñado en detalle — no es una spec de implementación, es el
registro de un cambio de paradigma identificado durante la investigación de Beta.
**No implementar todavía.** Ver `docs/SPRINT_BETA_CREDIBILIDAD_BACKLOG.md` para qué se hace
en la beta mientras tanto.

---

## El hallazgo que originó esto

Investigando por qué una comparación estructural daba `IoU 0.069` con alta coincidencia
visual real (job X-Men, ver `docs/CHANGELOG.md` y `docs/SPRINT_BETA_CREDIBILIDAD_BACKLOG.md`
Frente 2), se llegó a la causa raíz: el modelo de composición actual
(`light_through *= (1.0 - ink)` en `app.py`) trata **toda** tinta como absorbente/translúcida.
Es correcto para tintas de proceso (CMYK). Es incorrecto para blanco usado como aclarador
óptico en serigrafía — que refleja luz en vez de absorberla.

Isaac (Product Owner / domain expert) identificó que este no es un caso aislado. Es un
patrón que se repite cada vez que una separación no representa "color visible" sino
**función dentro del proceso de impresión**:

| Canal / técnica | Lo que el algoritmo asume hoy | Lo que realmente es |
|---|---|---|
| `WHITE` (aclarador) | Color visible | Modificador óptico (aclara lo que tiene debajo) |
| `UNDERBASE` | Contenido | Paso de proceso (opacidad sobre prenda oscura) |
| `HIGHLIGHT WHITE` | Objeto blanco | Aclarador puntual |
| `Metallic Gold` | Amarillo brillante | Amarillo + Metallic 872 + Highlight blanco (combinación) |
| `Negro desgastado` | Menos negro | Negro sólido + trama de base + discharge (combinación) |
| `Piel` | Una tinta "piel" | Blanco + Rojo + Amarillo (combinación, sin tinta propia) |

## El cambio de pregunta

**Hoy** el comparador estructural responde: *¿esta separación se parece al arte de
referencia, píxel a píxel?*

**La pregunta que un impresor realmente necesita responder es distinta:** *¿esta
separación va a producir el mismo resultado impreso?*

No son la misma pregunta. La primera compara imágenes. La segunda compara **lógica de
impresión** — qué combinación de tintas, en qué orden, con qué función cada una, produce
el resultado visual esperado.

## Por qué esto no es "agregar reglas al comparador actual"

Se podría intentar parchear caso por caso (excluir `WHITE`, excluir `UNDERBASE`, excluir
`HIGHLIGHT WHITE`...) pero eso reproduce exactamente el error que
`docs/ADR/ADR-012.md` ya identificó: ir agregando excepciones ad-hoc en vez of resolver la
causa de raíz. La causa de raíz acá es que el comparador no tiene ningún concepto de **rol**
de una tinta dentro del proceso — solo ve "hay tinta" o "no hay tinta".

## Conexión con el Knowledge Engine — por qué esto no es trabajo nuevo desde cero

Esto es, en gran parte, la razón por la que `core/knowledge/domain/` (Domain Vocabulary,
hoy aislado sin consumidor — ver `docs/ADR/ADR-006.md`) se diseñó con categorías más allá
de "color": `DOMAIN_CATEGORIES` ya incluye `Technique`, `TechniqueModifier`, `Production`,
`Effect` — conceptualmente adyacentes a lo que hace falta acá. Y
`docs/KNOWLEDGE_INFO_SPEC_v1.0.md` ya reservó un campo `semanticRoles` (no implementado en
v1) pensado para exactamente este tipo de anotación por token.

La pieza que falta y que ninguno de los dos documentos cubre todavía es un concepto nuevo:
**rol de tinta dentro del proceso** (aclarador / contenido / underbase / discharge /
highlight), distinto de "categoría de la palabra" (que es lo que el Domain Vocabulary
resuelve hoy). Un Production-Aware Comparison Engine consumiría esa anotación para decidir
**cómo componer** cada canal (absorbente vs reflectivo vs proceso) antes de comparar, en
vez de tratar todo canal por igual.

## Forma aproximada (no comprometida, para discusión futura)

```
Referencia (imagen)
        +
Separaciones (con INK ROLE por canal: content | lightener | underbase | discharge | ...)
        ↓
Production-Aware Compositor
   (compone cada canal según su rol físico real, no como absorción uniforme)
        ↓
Composite "esperado" físicamente correcto
        ↓
Comparación (ahora sí, estructural/pixel, contra este composite correcto)
```

El comparador estructural actual (`compare_structural_images`, `ink_mask_from_image`) no
desaparece — deja de operar sobre un composite mal construido y empieza a operar sobre uno
que sí representa la física del proceso.

## Qué NO decide este documento

- No decide el mecanismo exacto de composición por rol (interpolación óptica real vs.
  exclusión simple vs. algo intermedio).
- No decide si "ink role" se detecta automáticamente por nombre de canal (como
  `is_reinforcement_channel_name` hoy) o se declara explícitamente por el usuario al
  cargar el trabajo.
- No decide el orden de implementación relativo a Preflight, Producer Adapters, ni al resto
  de v1.1/v2.0 en `docs/ROADMAP.md`.

Estas son decisiones de diseño reales que necesitan su propia revisión de arquitectura
cuando llegue el momento — este documento solo dejar registrado *que existe* el problema y
*por qué* la solución correcta no es un parche sobre el comparador actual.
