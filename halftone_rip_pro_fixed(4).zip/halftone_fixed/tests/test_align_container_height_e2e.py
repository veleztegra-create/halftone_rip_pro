# Prueba end-to-end (navegador real, Playwright). Ver docs/CHANGELOG.md.
# Requiere: pip install playwright pillow + playwright install chromium.

import subprocess, time, sys, base64, io, urllib.request, os
sys.path.insert(0, '/tmp')
from PIL import Image
from playwright.sync_api import sync_playwright

import os
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def make_test_png(color, size):
    img = Image.new('RGB', size, color=color)
    buf = io.BytesIO(); img.save(buf, format='PNG'); return buf.getvalue()

server_proc = subprocess.Popen(
    [sys.executable, '-c', 'import app; app.app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)'],
    cwd=PROJECT_DIR, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
)
ready = False
for _ in range(30):
    try:
        urllib.request.urlopen('http://127.0.0.1:5000/api/build_info', timeout=1)
        ready = True; break
    except Exception:
        time.sleep(0.5)
if not ready:
    server_proc.terminate(); print(server_proc.communicate(timeout=5)[0]); sys.exit(1)
print('Server listo.\n')

# Imagen MUY alta (formato retrato extremo, como un job real de 7150x10750)
with open('/tmp/_test_tall_ref_container.png', 'wb') as f:
    f.write(make_test_png((200, 50, 50), (400, 2200)))
base_data_url = 'data:image/png;base64,' + base64.b64encode(make_test_png((80, 80, 200), (400, 2200))).decode()

try:
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={'width': 1400, 'height': 900})
        page.goto('http://127.0.0.1:5000/', wait_until='networkidle')
        page.click('#tab-preview')
        page.wait_for_timeout(300)

        page.set_input_files('#ref-input', '/tmp/_test_tall_ref_container.png')
        page.wait_for_timeout(600)
        page.evaluate(f'''() => {{
            document.getElementById('align-base-img').src = "{base_data_url}";
        }}''')
        page.wait_for_timeout(400)

        box = page.eval_on_selector('#align-container', '''el => {
            const r = el.getBoundingClientRect();
            const cs = getComputedStyle(el);
            return {height: r.height, maxHeight: cs.maxHeight, overflowY: cs.overflowY, scrollHeight: el.scrollHeight};
        }''')
        viewport_h = 900
        print(f'Viewport height: {viewport_h}px')
        print(f'#align-container: {box}')
        print(f'Altura renderizada del contenedor: {box["height"]:.0f}px ({100*box["height"]/viewport_h:.0f}% del viewport)')
        print(f'Contenido real (scrollHeight) del contenedor: {box["scrollHeight"]}px -- se ve completo solo con scroll interno')

        assert box['height'] <= viewport_h * 0.70, f'El contenedor mide {box["height"]}px, más del 70% del viewport -- el cap no está funcionando'
        assert box['overflowY'] == 'auto', 'overflow-y debería ser auto para permitir scroll interno'
        assert box['scrollHeight'] > box['height'], 'La imagen debería ser más alta que el contenedor (para que el scroll interno tenga sentido en esta prueba)'
        print('\nOK -- el contenedor queda acotado a una altura razonable, con scroll propio,')
        print('en vez de estirarse sin límite y empujar los resultados fuera de vista.')

        # Confirmar que los resultados (diff-results) están a una distancia razonable
        # del tope de la página, no empujados muy abajo por una imagen gigante.
        results_top = page.eval_on_selector('#diff-results', 'el => el.getBoundingClientRect().top')
        print(f'\nPosición vertical de #diff-results desde el tope de la ventana: {results_top:.0f}px')

        browser.close()
finally:
    server_proc.terminate()
    try: server_proc.wait(timeout=5)
    except subprocess.TimeoutExpired: server_proc.kill()
