import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import hashlib
import colorsys
from backend.color_name_resolver import resolve_display_color


# --- OLD implementation, verbatim from app.py (before this change) ---
CMYK_COLORS_OLD = {
    'Cyan': (0, 180, 216),
    'Magenta': (230, 58, 110),
    'Yellow': (245, 200, 0),
    'Black': (26, 26, 46),
}

def get_color_for_separation_OLD(name, idx=0):
    name_lower = name.lower().strip()
    for cmyk_name, color in CMYK_COLORS_OLD.items():
        if cmyk_name.lower() in name_lower:
            return color
    color_map = {
        'rojo': (220, 20, 60), 'red': (220, 20, 60),
        'azul': (30, 144, 255), 'blue': (30, 144, 255),
        'verde': (34, 139, 34), 'green': (34, 139, 34),
        'amarillo': (255, 215, 0), 'yellow': (255, 215, 0),
        'naranja': (255, 140, 0), 'orange': (255, 140, 0),
        'morado': (128, 0, 128), 'purple': (128, 0, 128),
        'rosa': (255, 105, 180), 'pink': (255, 105, 180),
        'gris': (128, 128, 128), 'gray': (128, 128, 128), 'grey': (128, 128, 128),
        'blanco': (255, 255, 255), 'white': (255, 255, 255),
        'negro': (0, 0, 0), 'black': (0, 0, 0),
        'cafe': (139, 69, 19), 'brown': (139, 69, 19), 'marrón': (139, 69, 19),
        'turquesa': (64, 224, 208), 'teal': (64, 224, 208),
        'violeta': (238, 130, 238), 'violet': (238, 130, 238),
        'dorado': (255, 215, 0), 'gold': (255, 215, 0),
        'plateado': (192, 192, 192), 'silver': (192, 192, 192),
        'bronze': (205, 127, 50), 'bronce': (205, 127, 50),
        'cobre': (184, 115, 51), 'copper': (184, 115, 51),
    }
    for color_name, color in color_map.items():
        if color_name in name_lower:
            return color
    h = hashlib.md5(name_lower.encode()).hexdigest()
    hue = int(h[:8], 16) / 0xffffffff
    sat = 0.55 + (int(h[8:10], 16) / 255) * 0.25
    light = 0.45 + (int(h[10:12], 16) / 255) * 0.15
    r, g, b = colorsys.hls_to_rgb(hue, light, sat)
    return (int(r * 255), int(g * 255), int(b * 255))


print("=" * 70)
print("TEST 1: Equivalencia EXACTA para nombres SIN modificador")
print("=" * 70)
# Estos son los nombres reales vistos en los logs de Isaac + variantes
# comunes de placas de serigrafía, ninguno con modificador de tono.
no_modifier_cases = [
    'AMARILLO', 'BASE', 'CAFE', 'Negro', 'naranja', 'white', 'Cyan', 'Magenta',
    'Yellow', 'Black', 'rojo', 'red', 'azul', 'blue', 'verde', 'green',
    'morado', 'rosa', 'gris', 'blanco', 'negro', 'turquesa', 'violeta',
    'dorado', 'plateado', 'bronze', 'cobre', 'Spot 1', 'PANTONE 200C',
    'Ink7', '', 'AZUL',  # <- el caso real reportado, SIN modificador
]
mismatches = []
for name in no_modifier_cases:
    old = get_color_for_separation_OLD(name)
    new = resolve_display_color(name)
    status = "OK" if old == new else "MISMATCH"
    if old != new:
        mismatches.append((name, old, new))
    print(f"{status:8} {name!r:20} OLD={old} NEW={new}")

assert not mismatches, f"Encontrados mismatches: {mismatches}"
print("\nOK -- comportamiento IDÉNTICO al original en todos los casos sin modificador.\n")

print("=" * 70)
print("TEST 2: El caso reportado por Isaac -- 'AZUL OSCURO'")
print("=" * 70)
old_azul_oscuro = get_color_for_separation_OLD('AZUL OSCURO')
new_azul_oscuro = resolve_display_color('AZUL OSCURO')
print(f"OLD (bug reportado): {old_azul_oscuro} = #{old_azul_oscuro[0]:02x}{old_azul_oscuro[1]:02x}{old_azul_oscuro[2]:02x}")
print(f"NEW (corregido):     {new_azul_oscuro} = #{new_azul_oscuro[0]:02x}{new_azul_oscuro[1]:02x}{new_azul_oscuro[2]:02x}")
assert old_azul_oscuro == (30, 144, 255), "El OLD no reproduce el bug reportado -- algo no coincide"
assert new_azul_oscuro != old_azul_oscuro, "El NEW no corrigió nada"
r, g, b = new_azul_oscuro
r_o, g_o, b_o = old_azul_oscuro
assert (r + g + b) < (r_o + g_o + b_o), "El resultado 'oscuro' debería ser más oscuro (suma RGB menor), no lo es"
print("OK -- 'AZUL OSCURO' ahora es visiblemente más oscuro que el 'AZUL' base, y ya no es #1E90FF.\n")

print("=" * 70)
print("TEST 3: Modificadores nuevos -- claro/oscuro/muy oscuro, ES y EN")
print("=" * 70)
modifier_cases = [
    'azul claro', 'azul oscuro', 'azul muy oscuro', 'azul muy claro',
    'verde oscuro', 'verde claro', 'blue dark', 'blue light',
    'amarillo vibrante', 'rojo profundo', 'verde muy claro',
]
base_only = {
    'azul': (30, 144, 255), 'blue': (30, 144, 255),
    'verde': (34, 139, 34), 'green': (34, 139, 34),
    'amarillo': (255, 215, 0), 'rojo': (220, 20, 60),
}
for case in modifier_cases:
    result = resolve_display_color(case)
    # encontrar el color base correspondiente
    base = None
    for k, v in base_only.items():
        if k in case:
            base = v
            break
    is_darker = sum(result) < sum(base) if base and ('oscuro' in case or 'dark' in case or 'profundo' in case) else None
    is_lighter = sum(result) > sum(base) if base and ('claro' in case or 'light' in case or 'vibrante' in case) else None
    tag = ""
    if is_darker is True or is_lighter is True:
        tag = "OK (dirección de luminosidad correcta)"
    elif is_darker is False or is_lighter is False:
        tag = "FALLO -- dirección incorrecta"
    print(f"{case!r:22} -> #{result[0]:02x}{result[1]:02x}{result[2]:02x}  {tag}")
    if is_darker is False or is_lighter is False:
        raise AssertionError(f"Dirección de luminosidad incorrecta para {case!r}")

print("\nOK -- todos los modificadores mueven la luminosidad en la dirección correcta.\n")

print("=" * 70)
print("TEST 4: Consistencia -- 'muy oscuro' es MÁS oscuro que 'oscuro'")
print("=" * 70)
azul = resolve_display_color('azul')
azul_oscuro = resolve_display_color('azul oscuro')
azul_muy_oscuro = resolve_display_color('azul muy oscuro')
print(f"azul:          #{azul[0]:02x}{azul[1]:02x}{azul[2]:02x} (suma={sum(azul)})")
print(f"azul oscuro:   #{azul_oscuro[0]:02x}{azul_oscuro[1]:02x}{azul_oscuro[2]:02x} (suma={sum(azul_oscuro)})")
print(f"azul muy oscuro: #{azul_muy_oscuro[0]:02x}{azul_muy_oscuro[1]:02x}{azul_muy_oscuro[2]:02x} (suma={sum(azul_muy_oscuro)})")
assert sum(azul_muy_oscuro) < sum(azul_oscuro) < sum(azul), "El orden de intensidad no es monotónico"
print("OK -- azul > azul oscuro > azul muy oscuro, en ese orden de luminosidad.\n")

print("=" * 70)
print("TEST 5: Colores con identidad propia NO se tratan como modificador+base")
print("=" * 70)
navy = resolve_display_color('navy')
royal = resolve_display_color('royal blue')
kelly = resolve_display_color('kelly green')
assert navy == (0, 0, 128)
assert royal == (65, 105, 225)
assert kelly == (76, 187, 23)
# 'navy' contiene 'blue'? NO -- pero 'royal blue' SÍ contiene 'blue' como substring.
# Verificamos que la identidad propia gana sobre la detección de color base.
blue_base = resolve_display_color('blue')
assert royal != blue_base, "royal blue no debería colapsar al azul genérico"
print(f"navy       -> #{navy[0]:02x}{navy[1]:02x}{navy[2]:02x} (identidad propia, no 'blue + modificador')")
print(f"royal blue -> #{royal[0]:02x}{royal[1]:02x}{royal[2]:02x} (identidad propia, no colapsa a blue genérico)")
print(f"kelly green-> #{kelly[0]:02x}{kelly[1]:02x}{kelly[2]:02x} (identidad propia, no 'green + modificador')")
print("\nOK -- colores con identidad propia se resuelven antes que cualquier detección de modificador.\n")

print("=" * 70)
print("TODOS LOS TESTS PASARON")
print("=" * 70)
