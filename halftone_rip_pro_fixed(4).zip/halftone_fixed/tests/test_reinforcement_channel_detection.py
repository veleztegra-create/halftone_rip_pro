import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import app as app_module

is_reinforcement = app_module.is_reinforcement_channel_name

print("=" * 70)
print("TEST 1: Equivalencia -- nombres que YA se excluían siguen igual")
print("=" * 70)
already_worked = [
    'BASE', 'base', 'Refuerzo', 'UNDERBASE', 'under base', 'Highlight Blanco',
    'Blanco de Refuerzo',  # contiene 'refuerzo'
    'Base de refuerzo',
]
for name in already_worked:
    result = is_reinforcement(name)
    status = "OK" if result else "FALLO"
    print(f"{status:6} {name!r:30} -> {result}")
    assert result, f"Regresión: {name!r} debía seguir excluido y ya no lo está"
print("\nOK -- ningún caso previamente cubierto se rompió.\n")

print("=" * 70)
print("TEST 2: Nueva cobertura -- paridad EN agregada")
print("=" * 70)
new_coverage = ['Reinforcement', 'REINFORCEMENT LAYER', 'Highlight White', 'HIGHLIGHT WHITE']
for name in new_coverage:
    result = is_reinforcement(name)
    status = "OK" if result else "FALLO"
    print(f"{status:6} {name!r:30} -> {result}")
    assert result, f"Gap de paridad no corregido: {name!r} debería excluirse ahora"
print("\nOK -- paridad EN/ES completa para 'refuerzo'/'reinforcement' y 'highlight blanco'/'highlight white'.\n")

print("=" * 70)
print("TEST 3: GUARDA -- 'blanco'/'white' SUELTOS siguen SIN excluirse por defecto")
print("=" * 70)
# Este es el comportamiento que el docstring protege deliberadamente: un canal
# llamado simplemente "Blanco" o "White" podría ser contenido visible real
# (texto blanco sobre remera de color), no necesariamente un aclarador.
bare_white_cases = ['Blanco', 'blanco', 'White', 'BLANCO', 'Azul Blanco Claro']
for name in bare_white_cases:
    result = is_reinforcement(name)
    status = "OK (NO excluido, como debe ser)" if not result else "FALLO -- se excluyó sin deberse"
    print(f"{status:35} {name!r}")
    assert not result, f"Regresión de seguridad: {name!r} se está excluyendo por defecto y NO debería"
print("\nOK -- 'blanco'/'white' sueltos NO se excluyen por defecto, tal como exige el diseño original.\n")

print("=" * 70)
print("TEST 4: Mecanismo per-job YA existente resuelve el caso real (X-Men)")
print("=" * 70)
# Esto confirma que, sin ningún cambio de código, un usuario podía (y puede)
# resolver el caso de "blanco usado como aclarador" hoy mismo, escribiendo
# la palabra clave correspondiente en el campo 'reinforcement-keywords' de
# la UI (ya conectado end-to-end: preview.js -> app.py -> extra_keywords).
job_channel_name = 'BLANCO ACLARADOR'  # nombre plausible del canal real del job
without_keyword = is_reinforcement(job_channel_name)
with_keyword = is_reinforcement(job_channel_name, extra_keywords=['blanco aclarador'])
print(f"Sin keyword configurado:  is_reinforcement({job_channel_name!r}) = {without_keyword}")
print(f"Con keyword del usuario:  is_reinforcement({job_channel_name!r}, ['blanco aclarador']) = {with_keyword}")
assert not without_keyword, "Por defecto NO debería excluirse (correcto, es específico del job)"
assert with_keyword, "Con el keyword del usuario SÍ debería excluirse -- si falla, el mecanismo per-job está roto"
print("\nOK -- el mecanismo per-job (ya existente, ya conectado a la UI) resuelve el caso real hoy.\n")

print("=" * 70)
print("TODOS LOS TESTS PASARON")
print("=" * 70)
