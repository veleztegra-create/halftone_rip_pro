# Prueba end-to-end (navegador real, Playwright) del arrastre de la referencia
# desde el centro. Ver docs/CHANGELOG.md v0.4.4. Requiere: pip install playwright
# pillow, y `playwright install chromium` una vez. No corre en CI headless sin
# esas dependencias -- es una prueba de regresión manual/local, no parte de la
# suite automática liviana (tests/test_*.py sin sufijo _e2e sí lo son).
import subprocess, time, sys, base64, io, urllib.request
from PIL import Image
from playwright.sync_api import sync_playwright

import os
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def make_test_png(color, size=(300, 400)):
    img = Image.new('RGB', size, color=color)
    buf = io.BytesIO(); img.save(buf, format='PNG'); return buf.getvalue()

server_proc = subprocess.Popen(
    [sys.executable, '-c', 'import app; app.app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)'],
    cwd=PROJECT_DIR, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
)
ready = False
for _ in range(30):
    try:
        urllib.request.urlopen('http://127.0.0.1:5000/api/build_info', timeout=1)
        ready = True; break
    except Exception:
        time.sleep(0.5)
if not ready:
    server_proc.terminate(); print(server_proc.communicate(timeout=5)[0]); sys.exit(1)
print('Server listo.\n')

with open('/tmp/_test_ref_center_drag.png', 'wb') as f:
    f.write(make_test_png((200, 50, 50)))
base_png_b64 = base64.b64encode(make_test_png((80, 80, 200))).decode()
base_data_url = f'data:image/png;base64,{base_png_b64}'

try:
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={'width': 1400, 'height': 1000})
        page.goto('http://127.0.0.1:5000/', wait_until='networkidle')
        page.click('#tab-preview')
        page.wait_for_timeout(300)

        # Disparar el flujo REAL de carga vía el <input type="file"> real
        # (dispara onchange -> loadRefFile -> ... -> loadRefImage -> initAlignHandles)
        page.set_input_files('#ref-input', '/tmp/_test_ref_center_drag.png')
        page.wait_for_timeout(800)

        has_class = page.eval_on_selector('#ref-preview-img', 'el => el.classList.contains("align-editable")')
        print(f'¿align-editable presente tras carga REAL vía <input type=file>?: {has_class}')
        assert has_class, 'El flujo real de carga no activó align-editable -- revisar loadRefImage'

        # loadSeparationBase() no puede completar sin Ghostscript/job real en este
        # sandbox (early-return por falta de lastJobName). Se compensa SOLO esa
        # parte (el fondo), sin tocar nada del mecanismo bajo prueba.
        page.evaluate(f'''() => {{
            const baseImg = document.getElementById('align-base-img');
            baseImg.src = "{base_data_url}";
        }}''')
        page.wait_for_timeout(300)

        pe = page.eval_on_selector('#ref-preview-img', 'el => getComputedStyle(el).pointerEvents')
        print(f'pointer-events (flujo real): {pe}')
        assert pe == 'auto'

        box = page.eval_on_selector('#ref-preview-img', '''el => {
            const r = el.getBoundingClientRect();
            return {x: r.x + r.width/2, y: r.y + r.height/2, h: r.height};
        }''')
        print(f'Bounding box: {box}')

        x_before = page.eval_on_selector('#align-x', 'el => el.value')
        y_before = page.eval_on_selector('#align-y', 'el => el.value')
        print(f'align-x/align-y ANTES: {x_before}, {y_before}')

        page.mouse.move(box['x'], box['y'])
        page.mouse.down()
        page.mouse.move(box['x'] + 60, box['y'] + 40, steps=10)
        page.mouse.up()
        page.wait_for_timeout(300)

        x_after = page.eval_on_selector('#align-x', 'el => el.value')
        y_after = page.eval_on_selector('#align-y', 'el => el.value')
        print(f'align-x/align-y DESPUÉS de arrastrar (+60,+40): {x_after}, {y_after}')

        if x_after != x_before or y_after != y_before:
            print('\n*** CONFIRMADO END-TO-END COMPLETO: el arrastre real desde el centro mueve align-x/align-y. ***')
        else:
            print('\nAÚN sin cambio -- investigar más (ver salida completa arriba).')

        browser.close()
finally:
    server_proc.terminate()
    try: server_proc.wait(timeout=5)
    except subprocess.TimeoutExpired: server_proc.kill()
