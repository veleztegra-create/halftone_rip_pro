// ============================================================
// HALFTONE RIP PRO - RIP & Separaciones Module
// Maneja: upload, configuración, procesamiento, resultados
// ============================================================

const RipModule = (function() {
    'use strict';

    // === STATE ===
    let currentFile = null;
    let currentFileData = null;
    let processing = false;
    let lastJobName = null;
    let lastColorNames = [];
    const CHUNK_SIZE = 5 * 1024 * 1024;

    // === DOM CACHE ===
    const $ = (id) => document.getElementById(id);
    const $$ = (sel) => document.querySelectorAll(sel);

    // === RECENT JOBS (historial real, persistido en localStorage) ===
    const RECENT_JOBS_KEY = 'halftone_recent_jobs';
    const MAX_RECENT_JOBS = 8;

    function getRecentJobs() {
        try {
            var raw = localStorage.getItem(RECENT_JOBS_KEY);
            return raw ? JSON.parse(raw) : [];
        } catch (e) {
            return [];
        }
    }

    function saveRecentJob(entry) {
        try {
            var jobs = getRecentJobs();
            jobs = jobs.filter(function(j) { return j.originalName !== entry.originalName; });
            jobs.unshift(entry);
            jobs = jobs.slice(0, MAX_RECENT_JOBS);
            localStorage.setItem(RECENT_JOBS_KEY, JSON.stringify(jobs));
            renderRecentJobs();
        } catch (e) {
            console.warn('No se pudo guardar el historial de trabajos:', e);
        }
    }

    function formatRelativeTime(timestamp) {
        var diffMs = Date.now() - timestamp;
        var diffMin = Math.floor(diffMs / 60000);
        if (diffMin < 1) return 'hace un momento';
        if (diffMin < 60) return 'hace ' + diffMin + ' min';
        var diffH = Math.floor(diffMin / 60);
        if (diffH < 24) return 'hace ' + diffH + 'h';
        var diffD = Math.floor(diffH / 24);
        if (diffD === 1) return 'ayer';
        if (diffD < 7) return 'hace ' + diffD + ' días';
        return new Date(timestamp).toLocaleDateString();
    }

    function renderRecentJobs() {
        var list = $('recentJobsList');
        if (!list) return;
        var jobs = getRecentJobs();

        if (jobs.length === 0) {
            list.innerHTML = '<li style="color: var(--text-muted); font-style: italic;">Aún no has procesado ningún archivo.</li>';
            return;
        }

        list.innerHTML = jobs.map(function(job) {
            return '<li style="display: flex; align-items: center; justify-content: space-between; gap: 8px; color: var(--text-secondary);" title="' + job.colorCount + ' color(es) · ' + job.lpi + ' LPI · ' + job.dpi + ' DPI">' +
                '<span style="display:flex; align-items:center; gap:8px; overflow:hidden;">' +
                    '<span style="color: #4bc0c0; flex-shrink:0;">✔</span>' +
                    '<span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">' + job.originalName + '</span>' +
                '</span>' +
                '<span style="color: var(--text-muted); font-size: 0.75rem; flex-shrink:0;">' + formatRelativeTime(job.timestamp) + '</span>' +
            '</li>';
        }).join('');
    }

    // === INITIALIZATION ===
    function init() {
        bindEvents();
        updateLpiDisplay();
        renderRecentJobs();
        log('🚀 Módulo RIP inicializado', 'success');

        // Escuchar cambios de biblioteca ASE para refrescar
        window.addEventListener('library:changed', function(e) {
            if (lastJobName) {
                console.log('[RIP] Biblioteca cambiada, notificando a Preview...');
                window.dispatchEvent(new CustomEvent('rip:jobComplete', {
                    detail: { jobName: lastJobName, refresh: true }
                }));
            }
        });
    }

    function bindEvents() {
        // File upload
        var dropZone = $('dropZone');
        var fileInput = $('fileInput');
        var browseBtn = $('browseBtn');

        if (browseBtn && fileInput) {
            browseBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                fileInput.click();
            });
        }

        if (dropZone) {
            dropZone.addEventListener('dragover', onDragOver);
            dropZone.addEventListener('dragleave', onDragLeave);
            dropZone.addEventListener('drop', onDrop);
            dropZone.addEventListener('click', function(e) {
                if (e.target !== browseBtn) {
                    fileInput.click();
                }
            });
        }
        if (fileInput) fileInput.onchange = function(e) {
            if (e.target.files.length) handleFile(e.target.files[0]);
        };
        if ($('clearFile')) $('clearFile').onclick = resetFile;

        // Config inputs
        var lpiInput = $('lpi');
        var dpiSelect = $('dpi');
        if (lpiInput) lpiInput.addEventListener('input', updateLpiDisplay);
        if (dpiSelect) dpiSelect.addEventListener('change', updateLpiDisplay);

        // Process button
        var processBtn = $('processBtn');
        if (processBtn) processBtn.onclick = processSeparations;
    }

    // === FILE HANDLING ===
    function onDragOver(e) {
        e.preventDefault();
        var dropZone = $('dropZone');
        if (dropZone) dropZone.classList.add('dragover');
    }

    function onDragLeave() {
        var dropZone = $('dropZone');
        if (dropZone) dropZone.classList.remove('dragover');
    }

    function onDrop(e) {
        e.preventDefault();
        var dropZone = $('dropZone');
        if (dropZone) dropZone.classList.remove('dragover');
        if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
    }

    function handleFile(file) {
        var validTypes = ['pdf', 'ps'];
        var ext = file.name.split('.').pop().toLowerCase();

        if (validTypes.indexOf(ext) === -1) {
            alert(
                'Formato no soportado: .' + ext + '\n\n' +
                'Este programa trabaja con archivos .ps o .pdf, ya sea preseparados ' +
                'por placa (una página por color) o compuestos en CMYK/PDF-X4 ' +
                '(con todos los colores en la misma página).\n\n' +
                'EPS, PNG, JPG y TIFF no contienen información real de separación ' +
                'de tintas, así que no se aceptan.'
            );
            return;
        }

        currentFile = file;
        showFileInfo(file);
        uploadFileChunked(file);
    }

    function showFileInfo(file) {
        var fileInfo = $('fileInfo');
        var fileName = $('fileName');
        var dropZone = $('dropZone');
        var statSize = $('statSize');

        if (fileName) fileName.textContent = file.name;
        if (fileInfo) fileInfo.classList.remove('hidden');
        if (dropZone) dropZone.classList.add('hidden');
        if (statSize) statSize.textContent = (file.size / 1048576).toFixed(1) + ' MB';
    }

    function resetFile() {
        currentFile = null;
        currentFileData = null;
        if ($('fileInput')) $('fileInput').value = '';

        var fileInfo = $('fileInfo');
        var dropZone = $('dropZone');
        var processBtn = $('processBtn');
        var resultsPanel = $('resultsPanel');
        var statSize = $('statSize');
        var uploadProgress = $('uploadProgress');

        if (fileInfo) fileInfo.classList.add('hidden');
        if (dropZone) dropZone.classList.remove('hidden');
        if (processBtn) {
            processBtn.disabled = true;
            processBtn.textContent = 'Procesar Separaciones';
        }
        if (resultsPanel) resultsPanel.classList.add('hidden');
        if (statSize) statSize.textContent = '-';
        if (uploadProgress) uploadProgress.classList.add('hidden');
    }

    // === UPLOAD ===
    function generateUploadId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 6);
    }

    function uploadFileChunked(file) {
        var totalChunks = Math.ceil(file.size / CHUNK_SIZE);
        var uploadId = generateUploadId();
        var chunkIndex = 0;

        var progEl = $('uploadProgress');
        var progFill = $('uploadProgressFill');
        var progMsg = $('uploadProgressMsg');

        if (progEl) progEl.classList.remove('hidden');
        if (progFill) progFill.style.width = '0%';
        if (progMsg) progMsg.textContent = 'Subiendo... (0/' + totalChunks + ')';

        function sendChunk() {
            var start = chunkIndex * CHUNK_SIZE;
            var end = Math.min(start + CHUNK_SIZE, file.size);
            var blob = file.slice(start, end);

            var formData = new FormData();
            formData.append('file', blob, file.name);
            formData.append('filename', file.name);
            formData.append('chunk_index', chunkIndex);
            formData.append('total_chunks', totalChunks);
            formData.append('upload_id', uploadId);

            fetch('/api/upload_chunk', { method: 'POST', body: formData })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data.error) {
                        log('Error al subir: ' + data.error, 'error');
                        if (progEl) progEl.classList.add('hidden');
                        return;
                    }

                    chunkIndex++;
                    var pct = Math.round(chunkIndex / totalChunks * 100);
                    if (progFill) progFill.style.width = pct + '%';
                    if (progMsg) progMsg.textContent = 'Subiendo... (' + chunkIndex + '/' + totalChunks + ')';

                    if (data.success && data.filename && data.original_name) {
                        if (progEl) progEl.classList.add('hidden');
                        currentFileData = data;
                        if ($('processBtn')) $('processBtn').disabled = false;
                        log('✅ Archivo cargado: ' + data.original_name + ' (' + (data.file_size_mb || '?') + ' MB)', 'success');
                    } else {
                        sendChunk();
                    }
                })
                .catch(function(err) {
                    log('Error de red: ' + err.message, 'error');
                    if (progEl) progEl.classList.add('hidden');
                });
        }

        sendChunk();
    }

    // === CONFIG DISPLAY ===
    function updateLpiDisplay() {
        var lpi = parseInt($('lpi')?.value) || 55;
        var dpi = parseInt($('dpi')?.value) || 600;
        var ratio = (dpi / lpi).toFixed(1);

        if ($('lpiDisplay')) $('lpiDisplay').textContent = lpi;
        if ($('ratioDisplay')) $('ratioDisplay').textContent = dpi + ' DPI - ratio ' + ratio + ':1';
        if ($('statLpi')) $('statLpi').textContent = lpi;
        if ($('statDpi')) $('statDpi').textContent = dpi;
        if ($('statRatio')) $('statRatio').textContent = ratio;
    }

    // === PROCESS ===
    function processSeparations() {
        if (!currentFileData || processing) return;
        processing = true;

        var btn = $('processBtn');
        var progressPanel = $('progressPanel');
        var resultsPanel = $('resultsPanel');
        var logPanel = $('logPanel');
        var progressFill = $('progressFill');

        if (btn) {
            btn.disabled = true;
            btn.textContent = '⏳ Procesando...';
        }
        if (progressPanel) progressPanel.classList.remove('hidden');
        if (progressFill) progressFill.style.width = '0%';
        if (logPanel) logPanel.innerHTML = '';

        if (resultsPanel) resultsPanel.classList.remove('hidden');
        showSkeletons();

        var config = {
            lpi: parseFloat($('lpi')?.value) || 55,
            dpi: parseInt($('dpi')?.value) || 600,
            angle: parseFloat($('angle')?.value) || 45,
            dot_shape: $('dotShape')?.value || 'round',
            auto_angles: $('autoAngles')?.checked ?? true,
            separation_mode: 'preseparated'
        };

        log('Iniciando trabajo: ' + currentFileData.original_name);
        log('Config: ' + config.lpi + ' LPI - ' + config.dpi + ' DPI - Forma: ' + config.dot_shape);

        var earlySteps = [
            { pct: 15, msg: 'Validando archivo...' },
            { pct: 30, msg: 'Iniciando Ghostscript...' }
        ];

        var stepIdx = 0;
        updateProgress(5, 'Iniciando proceso...');

        var progressInterval = setInterval(function() {
            if (stepIdx < earlySteps.length) {
                updateProgress(earlySteps[stepIdx].pct, earlySteps[stepIdx].msg);
                log(earlySteps[stepIdx].msg);
                stepIdx++;
            } else {
                clearInterval(progressInterval);
                setIndeterminate('Procesando separaciones y semitonos (puede tardar según tamaño y DPI)...');
            }
        }, 700);

        fetch('/api/process', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                filename: currentFileData.filename,
                config: config
            })
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            clearInterval(progressInterval);
            if (data.error) throw new Error(data.error);

            updateProgress(100, 'Completado!');
            log('✅ Trabajo finalizado: ' + Object.keys(data.channels).length + ' canales generados', 'success');

            var zipPathNorm = data.zip_path.split('\\').join('/');
            var parts = zipPathNorm.split('/');
            lastJobName = parts[parts.length - 2] || null;
            lastColorNames = Object.keys(data.channels);

            saveRecentJob({
                originalName: currentFileData.original_name,
                jobName: lastJobName,
                timestamp: Date.now(),
                colorCount: lastColorNames.length,
                lpi: config.lpi,
                dpi: config.dpi
            });

            window.dispatchEvent(new CustomEvent('rip:jobComplete', {
                detail: { jobName: lastJobName, colorNames: lastColorNames, channels: data.channels }
            }));

            renderResults(data.channels, data.zip_path);
            renderWarnings(data.warnings || []);

            setTimeout(function() {
                if (progressPanel) progressPanel.classList.add('hidden');
                if (resultsPanel) resultsPanel.classList.remove('hidden');
            }, 500);

            processing = false;
            if (btn) {
                btn.disabled = false;
                btn.textContent = 'Procesar Separaciones';
            }
        })
        .catch(function(err) {
            clearInterval(progressInterval);
            log('❌ ERROR CRÍTICO: ' + err.message, 'error');
            alert('Error: ' + err.message);
            processing = false;
            if (btn) {
                btn.disabled = false;
                btn.textContent = 'Procesar Separaciones';
            }
        });
    }

    function updateProgress(percent, msg) {
        var fill = $('progressFill');
        var msgEl = $('progressMsg');
        if (fill) {
            fill.classList.remove('indeterminate');
            fill.style.width = percent + '%';
        }
        if (msgEl) {
            msgEl.textContent = msg + (percent < 100 && percent > 5 ? ' ' + percent + '%' : '');
            msgEl.classList.toggle('processing', percent < 100);
        }
    }

    function setIndeterminate(msg) {
        var fill = $('progressFill');
        var msgEl = $('progressMsg');
        if (fill) fill.classList.add('indeterminate');
        if (msgEl) {
            msgEl.textContent = msg;
            msgEl.classList.add('processing');
        }
    }

    // === RESULTS & WARNINGS RENDERING ===
    function renderWarnings(warnings) {
        warnings = warnings || [];
        var warningsPanel = $('warningsPanel');
        var warningsList = $('warningsList');
        if (!warningsPanel || !warningsList) return;

        if (!warnings || warnings.length === 0) {
            warningsPanel.style.display = 'none';
            return;
        }

        warningsList.innerHTML = '';
        warnings.forEach(function(w) {
            var li = document.createElement('li');
            li.textContent = w;
            warningsList.appendChild(li);
        });

        warningsPanel.style.display = 'block';
    }

    function showSkeletons(count) {
        count = count || 4;
        var grid = $('resultsGrid');
        if (!grid) return;
        var html = '';
        for (var i = 0; i < count; i++) {
            html += '<div class="sep-card" style="animation-delay:' + (i * 0.08) + 's">' +
                '<div class="skeleton skeleton-card"></div>' +
                '<div class="skeleton" style="height: 16px; width: 60%; margin-top: 12px;"></div>' +
                '<div class="skeleton" style="height: 12px; width: 40%; margin-top: 6px;"></div>' +
            '</div>';
        }
        grid.innerHTML = html;
    }

    function renderResults(channels, zipPath) {
        var grid = $('resultsGrid');
        var bulkDiv = $('bulkDownloads');
        if (!grid) return;

        grid.innerHTML = '';
        var colors = ['#00d4ff', '#ff4d8a', '#ffd166', '#a0a0b8', '#ff6384', '#36a2eb', '#ffce56', '#4bc0c0'];
        var idx = 0;

        var entries = Object.entries(channels);
        for (var i = 0; i < entries.length; i++) {
            var entry = entries[i];
            var name = entry[0];
            var ch = entry[1];
            var isSpot = !['Cyan', 'Magenta', 'Yellow', 'Black'].includes(name);
            var colorDot = colors[idx % colors.length];

            var card = document.createElement('div');
            card.className = 'sep-card';
            card.style.animationDelay = (idx * 0.05) + 's';
            card.classList.add('animate-fade-in');

            card.innerHTML =
                '<div class="sep-preview">' +
                    '<img src="' + ch.preview + '" alt="' + name + '" loading="lazy">' +
                '</div>' +
                '<span class="sep-badge ' + (isSpot ? 'spot' : 'cmyk') + '">' + (isSpot ? 'SPOT' : 'CMYK') + '</span>' +
                '<div class="sep-name" style="display:flex;align-items:center;gap:6px">' +
                    '<span style="width:8px;height:8px;border-radius:50%;background:' + colorDot + ';display:inline-block"></span>' +
                    name +
                '</div>' +
                '<div class="sep-dims">' + ch.size[0] + ' x ' + ch.size[1] + ' px</div>';

            grid.appendChild(card);
            idx++;
        }

        if (bulkDiv) {
            bulkDiv.innerHTML = '';

            var zipBtn = document.createElement('a');
            zipBtn.className = 'btn-dl primary';
            zipBtn.href = '/api/download/' + zipPath.split('\\').join('/').split('/').map(encodeURIComponent).join('/');
            zipBtn.innerHTML = '📦 Descargar ZIP';
            bulkDiv.appendChild(zipBtn);

            var pdfBtn = document.createElement('button');
            pdfBtn.className = 'btn-dl magenta';
            pdfBtn.innerHTML = '📄 Descargar PDF';
            pdfBtn.onclick = downloadPdf;
            bulkDiv.appendChild(pdfBtn);
        }
    }

    function downloadPdf() {
        if (!lastJobName) {
            alert('Primero debes procesar un archivo.');
            return;
        }

        var btn = document.querySelector('.btn-dl.magenta');
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '⏳ Generando PDF...';
            btn.style.opacity = '0.7';
        }

        log('Generando PDF...');

        fetch('/api/generate_pdf', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                job_name: lastJobName,
                color_names: lastColorNames
            })
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.error) throw new Error(data.error);

            log('✅ PDF generado: ' + data.pages + ' páginas', 'success');

            // pdf_path ya viene como ruta relativa desde el servidor
            var relPath = data.pdf_path.split('\\').join('/');

            var a = document.createElement('a');
            a.href = '/api/download/' + relPath.split('/').map(encodeURIComponent).join('/');
            a.download = 'separaciones.pdf';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        })
        .catch(function(err) {
            log('❌ Error PDF: ' + err.message, 'error');
            alert('Error al generar PDF: ' + err.message);
        })
        .finally(function() {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '📄 Descargar PDF';
                btn.style.opacity = '1';
            }
        });
    }

    // === LOGGING ===
    function log(msg, type) {
        type = type || 'info';
        var panel = $('logPanel');
        if (!panel) return;

        var entry = document.createElement('div');
        entry.className = 'log-entry ' + type;
        var time = new Date().toLocaleTimeString('es', { hour12: false });
        var prefix = type === 'error' ? '❌' : type === 'warn' ? '⚠️' : type === 'success' ? '✅' : '→';
        entry.textContent = '[' + time + '] ' + prefix + ' ' + msg;

        panel.appendChild(entry);
        panel.scrollTop = panel.scrollHeight;
    }

    // === PUBLIC API ===
    return {
        init: init,
        getLastJobName: function() { return lastJobName; },
        getLastColorNames: function() { return lastColorNames; }
    };
})();

// Auto-init when DOM ready
document.addEventListener('DOMContentLoaded', RipModule.init);