// ============================================================
// KNOWLEDGE ENGINE - Undefined Color Policy
// Única responsabilidad: decidir qué hacer cuando ColorMatcher
// no encuentra nada. No busca colores, no conoce la base de
// datos — solo aplica una estrategia sobre lo que el matcher
// le devuelve.
//
// Vive en policies/ porque mañana habrá otras: metallicPolicy,
// laserPolicy, puffPolicy, meshPolicy, todas con la misma forma.
// ============================================================

const UNDEFINED_COLOR_POLICY = {
    strategies: {
        MAP_TO_NEAREST: 'map_to_nearest',
        GENERATE_FROM_SIMILARITY: 'generate_from_similarity',
        USE_DEFAULT: 'use_default',
        ASK_USER: 'ask_user'
    },

    defaultStrategy: 'map_to_nearest',

    defaultColor: {
        display: "#CCCCCC",
        name: "color_no_definido"
    }
};

const UndefinedColorPolicy = {
    // `matcher` se inyecta (en vez de importar ColorMatcher directo)
    // para no atar la policy a una única implementación de búsqueda.
    resolve: (searchTerm, strategy, matcher) => {
        switch (strategy) {
            case UNDEFINED_COLOR_POLICY.strategies.MAP_TO_NEAREST: {
                const nearest = matcher.findNearestColor(searchTerm);
                if (nearest) {
                    return {
                        baseColor: nearest.key || null,
                        displayColor: nearest.displayColor,
                        modifier: nearest.appliedModifier || null,
                        confidence: nearest.appliedModifier ? 0.7 : 0.5,
                        warnings: [`"${searchTerm}" no coincide exactamente; se usó el color más cercano encontrado.`],
                        metadata: { strategy: 'mapped_to_nearest', matchScore: nearest.matchScore ?? null }
                    };
                }
                return UndefinedColorPolicy._fallback(searchTerm, 'use_default');
            }

            case UNDEFINED_COLOR_POLICY.strategies.USE_DEFAULT:
                return UndefinedColorPolicy._fallback(searchTerm, 'use_default');

            case UNDEFINED_COLOR_POLICY.strategies.ASK_USER:
                return {
                    baseColor: null,
                    displayColor: null,
                    modifier: null,
                    confidence: 0,
                    warnings: [`Color "${searchTerm}" no encontrado. ¿Deseas definirlo?`],
                    metadata: { strategy: 'ask_user', needsUserInput: true }
                };

            case UNDEFINED_COLOR_POLICY.strategies.GENERATE_FROM_SIMILARITY:
                // Reservado para un sprint futuro (interpolación de color).
                return UndefinedColorPolicy._fallback(searchTerm, 'use_default');

            default:
                return UndefinedColorPolicy._fallback(searchTerm, 'fallback');
        }
    },

    _fallback: (searchTerm, strategyLabel) => ({
        baseColor: null,
        displayColor: UNDEFINED_COLOR_POLICY.defaultColor.display,
        modifier: null,
        confidence: 0,
        warnings: [`Color "${searchTerm}" no reconocido; se usó un color por defecto.`],
        metadata: { strategy: strategyLabel, isFallback: true }
    })
};
