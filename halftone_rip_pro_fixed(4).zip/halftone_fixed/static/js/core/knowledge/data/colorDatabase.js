// ============================================================
// KNOWLEDGE ENGINE - Color Database
// Solo datos. Ninguna función de búsqueda vive aquí.
//
// `category` y `saturation` se removieron: no los leía ningún
// método (YAGNI). `semantic.family` SÍ se mantiene: lo usa
// ColorMatcher.findNearestColor para el scoring de aproximación.
// `semantic.warm` / `semantic.intensity` se removieron por la
// misma razón que category/saturation: nadie los consume todavía.
// Si el Knowledge Engine v2 los necesita, se reintroducen ahí.
// ============================================================

const COLOR_DATABASE = {
    yellow: {
        displayColor: "#FFD400",
        modifiers: {
            light: "#FFF27A",    // amarillo claro
            dark: "#C89A00",     // amarillo oscuro
            pale: "#FFF9C4",     // amarillo muy claro
            deep: "#B8860B",     // amarillo muy oscuro
            vibrant: "#FFEA00"   // amarillo vibrante
        },
        semantic: {
            family: "yellow"
        }
    },

    blue: {
        displayColor: "#0066CC",
        modifiers: {
            light: "#7DB8FF",    // azul claro
            dark: "#003E7A",     // azul oscuro
            pale: "#D4E8FF",     // azul muy claro
            deep: "#00264D",     // azul muy oscuro
            vibrant: "#0088FF"   // azul vibrante
        },
        semantic: {
            family: "blue"
        }
    },

    red: {
        displayColor: "#DC143C",
        modifiers: {
            light: "#FF6B8A",    // rojo claro
            dark: "#A00A2A",     // rojo oscuro
            pale: "#FFD1DC",     // rojo muy claro
            deep: "#660015",     // rojo muy oscuro
            vibrant: "#FF0033"   // rojo vibrante
        },
        semantic: {
            family: "red"
        }
    },

    green: {
        displayColor: "#2E8B57",
        modifiers: {
            light: "#6BC49A",    // verde claro
            dark: "#1E6B3A",     // verde oscuro
            pale: "#B8E6D0",     // verde muy claro
            deep: "#0F4222",     // verde muy oscuro
            vibrant: "#00CC66"   // verde vibrante
        },
        semantic: {
            family: "green"
        }
    }
};
