// ============================================================
// KNOWLEDGE ENGINE - Color Aliases
// Solo alias -> clave de color. Esto va a crecer mucho (nombres
// de industria, abreviaturas, nombres de Pantone comunes, jerga
// de clientes) así que vive separado de colorDatabase.js.
//
// Punto de partida: se agregaron los alias de "yellow" que
// se pidieron como ejemplo. blue/red/green quedaron con un set
// mínimo razonable — hay que seguir poblándolos a medida que
// aparezcan en producción real (ese es justamente el problema
// que este archivo existe para resolver).
// ============================================================

const COLOR_ALIASES = {
    yellow: [
        "yellow", "amarillo", "amarillo base", "amarillo puro",
        "lt yellow", "lt yel", "yel", "ylw", "y",
        "canary", "sunflower",
        "athletic gold", "vegas gold", "gold", "old gold",
        "golden", "mustard", "safety yellow"
    ],

    blue: [
        "blue", "azul", "azul base", "azul puro",
        "lt blue", "lt bl", "bl",
        "royal blue", "navy", "sky blue"
    ],

    red: [
        "red", "rojo", "rojo base", "rojo puro",
        "lt red", "rd",
        "cardinal red", "cherry red", "scarlet"
    ],

    green: [
        "green", "verde", "verde base", "verde puro",
        "lt green", "grn",
        "forest green", "kelly green", "hunter green"
    ]
};
