// ============================================================
// KNOWLEDGE ENGINE - Coordinator
// Punto de entrada público del Knowledge Engine.
//
// AHORA: delega la resolución de color a ColorResolver,
// manteniendo el Knowledge Engine aislado del origen de los datos.
// ============================================================

const KnowledgeEngine = (function () {

    function resolve(searchTerm, strategy) {
        const originalName = searchTerm || '';
        const normalizedName = originalName.toLowerCase().trim();

        if (!normalizedName) {
            return createKnowledgeInfo({
                originalName,
                normalizedName,
                displayColor: (typeof UndefinedColorPolicy !== 'undefined' && UndefinedColorPolicy.defaultColor)
                    ? UndefinedColorPolicy.defaultColor.display
                    : '#CCCCCC',
                confidence: 0,
                warnings: ['Entrada vacía; se usó un color por defecto.'],
                metadata: { strategy: 'use_default', isFallback: true }
            });
        }

        // ============================================================
        // DELEGAR A COLOR RESOLVER
        // (no sabe que existe ASE, solo que existe un resolver)
        // ============================================================
        var result;
        if (typeof ColorResolver !== 'undefined') {
            result = ColorResolver.resolve(originalName);
        } else {
            // Fallback: usar ColorMatcher directamente si ColorResolver no existe
            var fallbackResult = null;
            if (typeof ColorMatcher !== 'undefined' && ColorMatcher.findColorSmart) {
                fallbackResult = ColorMatcher.findColorSmart(normalizedName);
            }
            if (fallbackResult) {
                result = {
                    found: true,
                    hex: fallbackResult.displayColor,
                    source: 'matcher',
                    confidence: 0.8,
                    metadata: {
                        key: fallbackResult.key,
                        modifier: fallbackResult.appliedModifier || null
                    }
                };
            } else {
                result = {
                    found: false,
                    hex: '#CCCCCC',
                    source: 'fallback',
                    confidence: 0,
                    metadata: { reason: 'no_resolver_available' }
                };
            }
        }

        var info = createKnowledgeInfo({
            originalName: originalName,
            normalizedName: normalizedName,
            baseColor: result.metadata && result.metadata.key ? result.metadata.key : null,
            displayColor: result.hex || '#CCCCCC',
            modifier: result.metadata && result.metadata.modifier ? result.metadata.modifier : null,
            confidence: result.confidence || 0,
            warnings: result.metadata && result.metadata.warnings ? result.metadata.warnings : [],
            metadata: {
                source: result.source || 'unknown',
                sourceMetadata: result.metadata || {}
            }
        });

        return info;
    }

    return { resolve };
})();