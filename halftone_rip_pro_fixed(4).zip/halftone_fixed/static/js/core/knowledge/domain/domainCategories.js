// ============================================================
// DOMAIN VOCABULARY - Categories
// El "part of speech" del idioma que habla Halftone RIP Pro.
// Esto es ADR-006: el vocabulario se define ANTES que cualquier
// algoritmo de interpretación (tokenizer, colorInterpreter, etc.).
//
// No es exhaustivo a propósito. Se agregan categorías cuando
// aparece una palabra real que las necesita, no antes.
// ============================================================

const DOMAIN_CATEGORIES = {
    MODIFIER: 'Modifier',                   // dark, light — intensidad tonal
    BASE_COLOR: 'BaseColor',                // gold, silver, white — el color en sí
    COLOR_QUALIFIER: 'ColorQualifier',      // athletic, vegas, old — califica un BaseColor
    TECHNIQUE: 'Technique',                 // metallic, puff, laser — técnica de impresión
    TECHNIQUE_MODIFIER: 'TechniqueModifier',// reflective — modifica una Technique
    PRODUCTION: 'Production',               // mesh — parámetro de producción
    EFFECT: 'Effect',                       // hd — efecto visual/acabado
    PANTONE_FAMILY: 'PantoneFamily'         // 872C — no es una palabra, es un patrón (ver domainPatterns.js)
};
