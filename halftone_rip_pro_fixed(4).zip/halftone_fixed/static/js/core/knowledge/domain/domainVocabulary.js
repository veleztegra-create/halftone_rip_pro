// ============================================================
// DOMAIN VOCABULARY - Word -> Category
// Diccionario del dominio. Solo datos: qué es cada palabra,
// no qué hacer con ella. ADR-006: esto se define antes que
// cualquier tokenizer/interpreter.
//
// FORMA DE CADA ENTRADA:
//   { categories: [...], primary: '<una de categories>' }
//
// ¿Por qué `categories` es un arreglo y no un string único?
// Porque algunas palabras del dominio son legítimamente
// ambiguas según el contexto (ver nota de HD y Reflective más
// abajo). Forzar una única categoría acá sería tomar una
// decisión de desambiguación — eso es trabajo del intérprete
// (sprint futuro), no del vocabulario.
//
// `primary` es la lectura más común/por defecto; el intérprete
// puede sobreescribirla usando contexto (palabras vecinas) el
// día que exista.
//
// GAPS CONOCIDOS (documentados a propósito, no resueltos):
// - "silver", "white", "black" están tageados como BaseColor
//   acá, pero NO existen todavía en colorDatabase.js (solo hay
//   yellow/blue/red/green). Este archivo describe el lenguaje;
//   no implica que el color ya sea resoluble a hex.
// - Los códigos tipo Pantone ("872C", "200U") no son palabras
//   de diccionario — son un patrón. Ver domainPatterns.js.
// ============================================================

const DOMAIN_VOCABULARY = {
    // --- Modifiers ---
    dark: { categories: [DOMAIN_CATEGORIES.MODIFIER], primary: DOMAIN_CATEGORIES.MODIFIER },
    light: { categories: [DOMAIN_CATEGORIES.MODIFIER], primary: DOMAIN_CATEGORIES.MODIFIER },

    // --- Techniques ---
    metallic: { categories: [DOMAIN_CATEGORIES.TECHNIQUE], primary: DOMAIN_CATEGORIES.TECHNIQUE },
    puff: { categories: [DOMAIN_CATEGORIES.TECHNIQUE], primary: DOMAIN_CATEGORIES.TECHNIQUE },
    laser: { categories: [DOMAIN_CATEGORIES.TECHNIQUE], primary: DOMAIN_CATEGORIES.TECHNIQUE },

    // AMBIGUO (ver nota en el header): en el ejemplo de vocabulario
    // "HD" es Technique; en "White Puff HD" se lee como Effect.
    // Se declaran ambas; primary = Effect porque "HD" casi siempre
    // aparece describiendo un acabado sobre otra técnica, no como
    // la técnica principal.
    hd: {
        categories: [DOMAIN_CATEGORIES.TECHNIQUE, DOMAIN_CATEGORIES.EFFECT],
        primary: DOMAIN_CATEGORIES.EFFECT
    },

    // AMBIGUO: en el vocabulario base "Reflective" es Technique;
    // en "Laser Cut Reflective Silver" se lee como TechniqueModifier
    // (modifica a "Silver", no es la técnica en sí). primary =
    // TechniqueModifier porque casi siempre acompaña a un
    // BaseColor o a otra Technique, no aparece sola.
    reflective: {
        categories: [DOMAIN_CATEGORIES.TECHNIQUE, DOMAIN_CATEGORIES.TECHNIQUE_MODIFIER],
        primary: DOMAIN_CATEGORIES.TECHNIQUE_MODIFIER
    },

    // --- Production ---
    mesh: { categories: [DOMAIN_CATEGORIES.PRODUCTION], primary: DOMAIN_CATEGORIES.PRODUCTION },

    // --- Color Qualifiers ---
    athletic: { categories: [DOMAIN_CATEGORIES.COLOR_QUALIFIER], primary: DOMAIN_CATEGORIES.COLOR_QUALIFIER },
    vegas: { categories: [DOMAIN_CATEGORIES.COLOR_QUALIFIER], primary: DOMAIN_CATEGORIES.COLOR_QUALIFIER },
    old: { categories: [DOMAIN_CATEGORIES.COLOR_QUALIFIER], primary: DOMAIN_CATEGORIES.COLOR_QUALIFIER },

    // --- Base Colors ---
    // "gold" ya es resoluble hoy (alias de "yellow" en aliases.js).
    gold: { categories: [DOMAIN_CATEGORIES.BASE_COLOR], primary: DOMAIN_CATEGORIES.BASE_COLOR },

    // "silver", "white", "black": categorizados como lenguaje del
    // dominio, pero SIN resolución a hex todavía (gap documentado
    // arriba). Se incluyen para que el vocabulario sea honesto
    // sobre qué palabras existen en el idioma, no sobre qué ya
    // está implementado.
    silver: { categories: [DOMAIN_CATEGORIES.BASE_COLOR], primary: DOMAIN_CATEGORIES.BASE_COLOR },
    white: { categories: [DOMAIN_CATEGORIES.BASE_COLOR], primary: DOMAIN_CATEGORIES.BASE_COLOR },
    black: { categories: [DOMAIN_CATEGORIES.BASE_COLOR], primary: DOMAIN_CATEGORIES.BASE_COLOR }
};
