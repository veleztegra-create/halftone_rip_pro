// ============================================================
// DOMAIN VOCABULARY - Patterns
// DOMAIN_VOCABULARY solo puede describir un conjunto CERRADO de
// palabras. Pero cosas como "872C" o "200U" son una clase
// ABIERTA — no se pueden enumerar en un diccionario. Necesitan
// un patrón, no una entrada literal.
//
// Esto sigue siendo declarativo (una tabla de patrones), no un
// algoritmo de reconocimiento. Ejecutar estos patrones contra un
// texto real es trabajo del intérprete (sprint futuro) — acá
// solo se declara que el patrón existe y a qué categoría del
// dominio corresponde.
// ============================================================

const DOMAIN_PATTERNS = [
    {
        name: 'pantoneStyleCode',
        pattern: /^\d{3,4}[a-z]{0,2}$/i,
        category: DOMAIN_CATEGORIES.PANTONE_FAMILY,
        description: 'Códigos estilo Pantone: 872C, 200U, 7405CP, etc.'
    }
];
