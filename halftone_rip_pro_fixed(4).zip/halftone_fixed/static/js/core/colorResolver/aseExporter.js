// ============================================================
// ASE EXPORTER
// Generación de archivos Adobe Swatch Exchange (.ase)
// ============================================================

const AseExporter = (function() {
    'use strict';

    // Función auxiliar para escribir UTF-16LE
    function writeString(view, offset, str) {
        var pos = offset;
        for (var i = 0; i < str.length; i++) {
            view.setUint16(pos, str.charCodeAt(i), true);
            pos += 2;
        }
        view.setUint16(pos, 0, true); // null terminator
        return pos + 2;
    }

    function writeUint32(view, offset, value) {
        view.setUint32(offset, value, false);
        return offset + 4;
    }

    function writeUint16(view, offset, value) {
        view.setUint16(offset, value, false);
        return offset + 2;
    }

    function writeUint8(view, offset, value) {
        view.setUint8(offset, value);
        return offset + 1;
    }

    function hexToRgb(hex) {
        var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? [
            parseInt(result[1], 16),
            parseInt(result[2], 16),
            parseInt(result[3], 16)
        ] : [0, 0, 0];
    }

    function rgbToCmyk(r, g, b) {
        var rNorm = r / 255;
        var gNorm = g / 255;
        var bNorm = b / 255;

        var k = 1 - Math.max(rNorm, gNorm, bNorm);
        if (k === 1) return [0, 0, 0, 1];

        var c = (1 - rNorm - k) / (1 - k);
        var m = (1 - gNorm - k) / (1 - k);
        var y = (1 - bNorm - k) / (1 - k);

        return [c, m, y, k];
    }

    /**
     * Genera un archivo .ase a partir de una biblioteca de colores
     * @param {Object} library - { name: string, colors: { nombre: { hex, rgb, cmyk } } }
     * @returns {ArrayBuffer} Datos del archivo .ase
     */
    function generate(library) {
        var colors = library.colors || {};
        var colorEntries = Object.entries(colors);

        // Estimar tamaño: header + 4 bytes por bloque + datos
        var estimatedSize = 1024 + colorEntries.length * 256;
        var buffer = new ArrayBuffer(estimatedSize);
        var view = new DataView(buffer);
        var offset = 0;

        // === HEADER ===
        // "ASEF" - 4 bytes
        view.setUint8(offset, 0x41); // A
        view.setUint8(offset + 1, 0x53); // S
        view.setUint8(offset + 2, 0x45); // E
        view.setUint8(offset + 3, 0x46); // F
        offset += 4;

        // Version major (1) y minor (0)
        offset = writeUint16(view, offset, 1);
        offset = writeUint16(view, offset, 0);

        // Block count: 1 (NAME) + 1 por cada color
        var totalBlocks = 1 + colorEntries.length;
        offset = writeUint32(view, offset, totalBlocks);

        // === NAME BLOCK ===
        // Block type: 'NAME' = 0x4E414D45
        offset = writeUint32(view, offset, 0x4E414D45);

        // Block length (data): nombre + null terminator
        var nameStr = library.name || 'Biblioteca sin nombre';
        var nameBytes = nameStr.length * 2 + 2; // UTF-16LE + null terminator
        offset = writeUint32(view, offset, nameBytes);

        // Escribir nombre
        offset = writeString(view, offset, nameStr);

        // Padding de 4 bytes al final del bloque
        offset = writeUint32(view, offset, 0);

        // === COLOR BLOCKS ===
        for (var idx = 0; idx < colorEntries.length; idx++) {
            var entry = colorEntries[idx];
            var name = entry[0];
            var color = entry[1];

            var rgb = color.rgb || hexToRgb(color.hex || '#000000');
            var cmyk = color.cmyk || rgbToCmyk(rgb[0], rgb[1], rgb[2]);

            // Block type: 'SEGA' = 0x53454741
            offset = writeUint32(view, offset, 0x53454741);

            // Guardar posición para escribir block length después
            var lengthPos = offset;
            offset += 4;

            // Color mode: 0 = CMYK, 1 = RGB
            // Usar CMYK si tenemos valores válidos
            var useCmyk = cmyk && cmyk.every(function(v) { return v >= 0 && v <= 1; });

            // Escribir color mode
            offset = writeUint16(view, offset, useCmyk ? 0 : 1);

            // Escribir color data length (2 bytes por canal)
            var dataLength = useCmyk ? 8 : 6;
            offset = writeUint16(view, offset, dataLength);

            // Escribir valores de color
            if (useCmyk) {
                offset = writeUint16(view, offset, Math.round(cmyk[0] * 65535));
                offset = writeUint16(view, offset, Math.round(cmyk[1] * 65535));
                offset = writeUint16(view, offset, Math.round(cmyk[2] * 65535));
                offset = writeUint16(view, offset, Math.round(cmyk[3] * 65535));
            } else {
                offset = writeUint16(view, offset, Math.round((rgb[0] / 255) * 65535));
                offset = writeUint16(view, offset, Math.round((rgb[1] / 255) * 65535));
                offset = writeUint16(view, offset, Math.round((rgb[2] / 255) * 65535));
            }

            // Escribir nombre del color (longitud + string)
            var colorName = name || 'Color';
            var colorNameBytes = colorName.length * 2 + 2;
            offset = writeUint16(view, offset, colorNameBytes);
            offset = writeString(view, offset, colorName);

            // Padding de 4 bytes al final del bloque
            offset = writeUint32(view, offset, 0);

            // Volver y escribir block length
            var blockLength = offset - lengthPos - 4;
            view.setUint32(lengthPos, blockLength, false);
        }

        // Retornar el buffer con el tamaño real
        var result = new ArrayBuffer(offset);
        var resultView = new Uint8Array(result);
        var sourceView = new Uint8Array(buffer, 0, offset);
        resultView.set(sourceView);

        return result;
    }

    /**
     * Genera un archivo .ase y lo descarga
     * @param {Object} library - Biblioteca a exportar
     * @param {string} filename - Nombre del archivo
     */
    function download(library, filename) {
        var data = generate(library);
        var blob = new Blob([data], { type: 'application/octet-stream' });
        var url = URL.createObjectURL(blob);

        var a = document.createElement('a');
        a.href = url;
        a.download = filename || (library.name || 'biblioteca') + '.ase';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        setTimeout(function() { URL.revokeObjectURL(url); }, 1000);
    }

    // === PUBLIC API ===
    return {
        generate: generate,
        download: download
    };
})();