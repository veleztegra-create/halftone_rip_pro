// ============================================================
// BASE LIBRARY - Fuente de datos existente
// Wrapper sobre COLOR_DATABASE + COLOR_ALIASES
// ============================================================

var BaseLibrary = (function() {
    'use strict';

    // Construir un mapa de búsqueda rápido
    function buildLookup() {
        var lookup = {};

        // Verificar que COLOR_DATABASE exista
        if (typeof COLOR_DATABASE === 'undefined') {
            console.warn('[BaseLibrary] COLOR_DATABASE no definido');
            return lookup;
        }

        for (var key in COLOR_DATABASE) {
            if (COLOR_DATABASE.hasOwnProperty(key)) {
                var color = COLOR_DATABASE[key];

                // Clave principal
                lookup[key] = {
                    key: key,
                    displayColor: color.displayColor,
                    modifiers: color.modifiers,
                    semantic: color.semantic
                };

                // Aliases
                var aliases = (typeof COLOR_ALIASES !== 'undefined' && COLOR_ALIASES[key]) || [];
                for (var i = 0; i < aliases.length; i++) {
                    var normalized = aliases[i].toLowerCase().trim();
                    if (normalized && !lookup[normalized]) {
                        lookup[normalized] = {
                            key: key,
                            displayColor: color.displayColor,
                            modifiers: color.modifiers,
                            semantic: color.semantic,
                            isAlias: true,
                            aliasOf: key
                        };
                    }
                }
            }
        }

        return lookup;
    }

    var lookup = buildLookup();

    function normalizeName(name) {
        return (name || '').trim().toLowerCase();
    }

    function resolve(name) {
        var normalized = normalizeName(name);
        if (!normalized) return null;

        var match = lookup[normalized];
        if (!match) return null;

        return {
            found: true,
            hex: match.displayColor,
            key: match.key,
            modifiers: match.modifiers || null,
            semantic: match.semantic || null,
            isAlias: match.isAlias || false,
            aliasOf: match.aliasOf || null
        };
    }

    function resolveWithModifier(name) {
        var normalized = normalizeName(name);
        if (!normalized) return null;

        // Primero intentar búsqueda con modificador usando ColorMatcher si existe
        if (typeof ColorMatcher !== 'undefined' && ColorMatcher.findColorSmart) {
            var smart = ColorMatcher.findColorSmart(normalized);
            if (smart) {
                return {
                    found: true,
                    hex: smart.displayColor,
                    key: smart.key,
                    modifier: smart.appliedModifier,
                    isModified: smart.isModified || false
                };
            }
        }

        // Fallback a búsqueda simple
        return resolve(name);
    }

    function getColor(key) {
        if (typeof COLOR_DATABASE === 'undefined') return null;
        return COLOR_DATABASE[key] || null;
    }

    function getAliases(key) {
        if (typeof COLOR_ALIASES === 'undefined') return [];
        return COLOR_ALIASES[key] || [];
    }

    function getDatabase() {
        return typeof COLOR_DATABASE !== 'undefined' ? COLOR_DATABASE : {};
    }

    function getAliasesMap() {
        return typeof COLOR_ALIASES !== 'undefined' ? COLOR_ALIASES : {};
    }

    // === PUBLIC API ===
    return {
        resolve: resolve,
        resolveWithModifier: resolveWithModifier,
        getColor: getColor,
        getAliases: getAliases,
        getDatabase: getDatabase,
        getAliasesMap: getAliasesMap
    };
})();