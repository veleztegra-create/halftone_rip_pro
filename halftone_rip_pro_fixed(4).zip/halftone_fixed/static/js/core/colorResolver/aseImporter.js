// ============================================================
// ASE IMPORTER
// Parseo de archivos Adobe Swatch Exchange (.ase)
// ============================================================

const AseImporter = (function() {
    'use strict';

    /**
     * Parsea un archivo .ase a un objeto de colores
     * @param {ArrayBuffer} buffer - Contenido del archivo .ase
     * @returns {Object} { name: string, colors: { nombre: { hex, rgb, cmyk } } }
     */
    function parse(buffer) {
        var view = new DataView(buffer);
        var offset = 0;

        // === HEADER ===
        // 4 bytes: "ASEF"
        var signature = String.fromCharCode(
            view.getUint8(offset),
            view.getUint8(offset + 1),
            view.getUint8(offset + 2),
            view.getUint8(offset + 3)
        );
        offset += 4;

        if (signature !== 'ASEF') {
            throw new Error('Archivo ASE inválido: firma incorrecta');
        }

        // 2 bytes: version major
        var versionMajor = view.getUint16(offset, false);
        offset += 2;

        // 2 bytes: version minor
        var versionMinor = view.getUint16(offset, false);
        offset += 2;

        console.log('[ASE] Versión: ' + versionMajor + '.' + versionMinor);

        // 4 bytes: block count
        var blockCount = view.getUint32(offset, false);
        offset += 4;

        console.log('[ASE] ' + blockCount + ' bloques');

        var colors = {};
        var libraryName = 'Biblioteca ASE';

        for (var i = 0; i < blockCount; i++) {
            var result = parseBlock(view, offset);
            if (result) {
                if (result.type === 'name') {
                    libraryName = result.value;
                } else if (result.type === 'color' && result.color) {
                    var name = result.color.name;
                    if (name && result.color.hex) {
                        colors[name] = {
                            hex: result.color.hex,
                            rgb: result.color.rgb || null,
                            cmyk: result.color.cmyk || null
                        };
                    }
                }
            }
            offset = result ? result.nextOffset : offset;
        }

        console.log('[ASE] Importados ' + Object.keys(colors).length + ' colores de "' + libraryName + '"');

        return {
            name: libraryName,
            colors: colors,
            colorCount: Object.keys(colors).length,
            version: versionMajor + '.' + versionMinor
        };
    }

    function parseBlock(view, offset) {
        var startOffset = offset;

        // 4 bytes: block type
        var blockType = view.getUint32(offset, false);
        offset += 4;

        // 4 bytes: block length (data)
        var blockLength = view.getUint32(offset, false);
        offset += 4;

        var dataStart = offset;
        var dataEnd = offset + blockLength;

        var result = null;

        switch (blockType) {
            case 0x54454741: // 'TEGA' - Grupo
                // Saltar el nombre del grupo (no nos interesa por ahora)
                break;

            case 0x53454741: // 'SEGA' - Color
                result = parseColorBlock(view, dataStart, dataEnd);
                break;

            case 0x4C4F434B: // 'LOCK' - Grupo bloqueado
                break;

            case 0x4944454E: // 'IDEN' - Identificación del archivo
                break;

            case 0x4E414D45: // 'NAME' - Nombre del archivo
                var name = readString(view, dataStart);
                if (name) {
                    result = { type: 'name', value: name };
                }
                break;

            default:
                // Tipo desconocido, saltar
                break;
        }

        return {
            result: result,
            nextOffset: dataEnd + 4 // +4 porque hay 4 bytes de padding al final
        };
    }

    function parseColorBlock(view, start, end) {
        var offset = start;

        // 2 bytes: color mode
        var colorMode = view.getUint16(offset, false);
        offset += 2;

        // 2 bytes: color data length
        var colorDataLength = view.getUint16(offset, false);
        offset += 2;

        // Extraer valores según el modo
        var rgb = null;
        var cmyk = null;
        var hex = '#000000';

        switch (colorMode) {
            case 0: // CMYK
                var c = view.getUint16(offset, false) / 65535;
                offset += 2;
                var m = view.getUint16(offset, false) / 65535;
                offset += 2;
                var y = view.getUint16(offset, false) / 65535;
                offset += 2;
                var k = view.getUint16(offset, false) / 65535;
                offset += 2;
                cmyk = [c, m, y, k];
                rgb = cmykToRgb(c, m, y, k);
                hex = rgbToHex(rgb[0], rgb[1], rgb[2]);
                break;

            case 1: // RGB
                var r = view.getUint16(offset, false) / 65535;
                offset += 2;
                var g = view.getUint16(offset, false) / 65535;
                offset += 2;
                var b = view.getUint16(offset, false) / 65535;
                offset += 2;
                rgb = [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
                hex = rgbToHex(rgb[0], rgb[1], rgb[2]);
                break;

            case 2: // LAB
                // Saltar LAB por ahora (convertir a RGB podría ser complejo)
                offset += colorDataLength;
                return null;

            default:
                return null;
        }

        // 2 bytes: color name length (incluye null terminator)
        var nameLength = view.getUint16(offset, false);
        offset += 2;

        // String (UTF-16LE)
        var name = readString(view, offset, nameLength);
        offset += nameLength;

        return {
            type: 'color',
            color: {
                name: name,
                rgb: rgb,
                cmyk: cmyk,
                hex: hex
            }
        };
    }

    function readString(view, offset, maxLength) {
        var chars = [];
        var i = 0;
        var currentOffset = offset;

        while (maxLength ? i < maxLength - 1 : true) {
            var charCode = view.getUint16(currentOffset, true);
            currentOffset += 2;
            i += 2;

            if (charCode === 0) break;
            chars.push(String.fromCharCode(charCode));

            if (maxLength && i >= maxLength) break;
        }

        return chars.join('') || null;
    }

    function cmykToRgb(c, m, y, k) {
        var r = Math.round(255 * (1 - c) * (1 - k));
        var g = Math.round(255 * (1 - m) * (1 - k));
        var b = Math.round(255 * (1 - y) * (1 - k));
        return [r, g, b];
    }

    function rgbToHex(r, g, b) {
        return '#' + [r, g, b].map(function(c) {
            var clamped = Math.max(0, Math.min(255, Math.round(c)));
            return clamped.toString(16).padStart(2, '0');
        }).join('');
    }

    /**
     * Lee un archivo .ase desde un File object
     * @param {File} file - Archivo .ase
     * @returns {Promise<Object>} Datos parseados
     */
    function parseFile(file) {
        return new Promise(function(resolve, reject) {
            var reader = new FileReader();
            reader.onload = function(e) {
                try {
                    var result = parse(e.target.result);
                    resolve(result);
                } catch (err) {
                    reject(err);
                }
            };
            reader.onerror = function() { reject(new Error('Error al leer el archivo')); };
            reader.readAsArrayBuffer(file);
        });
    }

    // === PUBLIC API ===
    return {
        parse: parse,
        parseFile: parseFile
    };
})();