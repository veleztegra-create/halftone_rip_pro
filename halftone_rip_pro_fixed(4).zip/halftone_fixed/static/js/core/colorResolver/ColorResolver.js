// ============================================================
// COLOR RESOLVER
// Único punto de entrada para resolver nombres de color a
// colores de visualización.
//
// Orden de resolución:
// 1. Biblioteca activa (ASE) - match exacto
// 2. BaseLibrary (existente) - match exacto + alias
// 3. ColorMatcher (existente) - modificadores + aproximación
// 4. UndefinedColorPolicy (existente)
// ============================================================

const ColorResolver = (function() {
    'use strict';

    function normalizeName(name) {
        return (name || '').trim().toLowerCase();
    }

    /**
     * Resuelve un nombre de color a un color de visualización
     * @param {string} name - Nombre del color a resolver
     * @returns {Object} {
     *   found: boolean,
     *   hex: string (si found),
     *   rgb: [r,g,b] (opcional),
     *   cmyk: [c,m,y,k] (opcional),
     *   source: 'ase_library' | 'base_library' | 'matcher' | 'fallback',
     *   confidence: 0-1,
     *   metadata: Object (información adicional según fuente)
     * }
     */
    function resolve(name) {
        const normalized = normalizeName(name);
        if (!normalized) {
            return {
                found: false,
                source: 'fallback',
                confidence: 0,
                metadata: { reason: 'empty_name' }
            };
        }

        // ============================================================
        // 1. Biblioteca activa (ASE) - match exacto
        // ============================================================
        if (ColorLibraryManager) {
            const aseResult = ColorLibraryManager.resolve(name);
            if (aseResult && aseResult.found) {
                return {
                    found: true,
                    hex: aseResult.hex,
                    rgb: aseResult.rgb || null,
                    cmyk: aseResult.cmyk || null,
                    source: 'ase_library',
                    confidence: 1,
                    metadata: {
                        libraryName: aseResult.libraryName,
                        libraryId: aseResult.libraryId,
                        originalName: aseResult.originalName
                    }
                };
            }
        }

        // ============================================================
        // 2. BaseLibrary (existente) - match exacto + alias
        // ============================================================
        if (BaseLibrary) {
            const baseResult = BaseLibrary.resolve(name);
            if (baseResult && baseResult.found) {
                return {
                    found: true,
                    hex: baseResult.hex,
                    rgb: null,
                    cmyk: null,
                    source: 'base_library',
                    confidence: 1,
                    metadata: {
                        key: baseResult.key,
                        isAlias: baseResult.isAlias || false,
                        aliasOf: baseResult.aliasOf || null,
                        semantic: baseResult.semantic || null
                    }
                };
            }
        }

        // ============================================================
        // 3. ColorMatcher (existente) - modificadores + aproximación
        // ============================================================
        if (ColorMatcher) {
            const matchResult = ColorMatcher.findColorSmart(normalized);
            if (matchResult) {
                return {
                    found: true,
                    hex: matchResult.displayColor,
                    rgb: null,
                    cmyk: null,
                    source: 'matcher',
                    confidence: matchResult.isApproximation ? 0.5 : 0.8,
                    metadata: {
                        key: matchResult.key,
                        modifier: matchResult.appliedModifier || null,
                        isModified: matchResult.isModified || false,
                        isApproximation: matchResult.isApproximation || false,
                        originalSearch: matchResult.originalSearch || null,
                        matchScore: matchResult.matchScore || null
                    }
                };
            }
        }

        // ============================================================
        // 4. UndefinedColorPolicy (existente)
        // ============================================================
        if (UndefinedColorPolicy) {
            const fallbackResult = UndefinedColorPolicy.resolve(name);
            return {
                found: true,
                hex: fallbackResult.displayColor || '#CCCCCC',
                rgb: null,
                cmyk: null,
                source: 'fallback',
                confidence: 0,
                metadata: {
                    strategy: fallbackResult.metadata?.strategy || 'use_default',
                    isFallback: true,
                    warnings: fallbackResult.warnings || []
                }
            };
        }

        // Último recurso
        return {
            found: true,
            hex: '#CCCCCC',
            rgb: null,
            cmyk: null,
            source: 'fallback',
            confidence: 0,
            metadata: { reason: 'no_policy_available' }
        };
    }

    /**
     * Resuelve un nombre y devuelve solo el hex
     * @param {string} name - Nombre del color
     * @returns {string} Hex del color o '#CCCCCC' si no se encuentra
     */
    function resolveHex(name) {
        const result = resolve(name);
        return result.found ? result.hex : '#CCCCCC';
    }

    /**
     * Resuelve un nombre y devuelve información completa con metadata
     * @param {string} name - Nombre del color
     * @returns {Object} Resultado completo
     */
    function resolveDetailed(name) {
        return resolve(name);
    }

    // === PUBLIC API ===
    return {
        resolve,
        resolveHex,
        resolveDetailed
    };
})();