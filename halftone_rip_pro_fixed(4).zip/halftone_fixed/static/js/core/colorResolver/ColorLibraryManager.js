// ============================================================
// COLOR LIBRARY MANAGER
// Persistencia y gestión de bibliotecas de color en localStorage
// ============================================================

const ColorLibraryManager = (function() {
    'use strict';

    var STORAGE_KEY = 'hrp_color_libraries';
    var ACTIVE_KEY = 'hrp_active_library';

    var libraries = {};
    var activeId = null;

    // === PRIVATE ===

    function loadFromStorage() {
        try {
            var raw = localStorage.getItem(STORAGE_KEY);
            libraries = raw ? JSON.parse(raw) : {};
        } catch (e) {
            libraries = {};
        }

        try {
            activeId = localStorage.getItem(ACTIVE_KEY);
            if (activeId && !libraries[activeId]) {
                activeId = null;
            }
        } catch (e) {
            activeId = null;
        }
    }

    function saveToStorage() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(libraries));
            if (activeId) {
                localStorage.setItem(ACTIVE_KEY, activeId);
            } else {
                localStorage.removeItem(ACTIVE_KEY);
            }
        } catch (e) {
            console.warn('[ColorLibraryManager] No se pudo guardar en localStorage:', e);
        }
    }

    function generateId() {
        return 'lib_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6);
    }

    function normalizeName(name) {
        return (name || '').trim().toLowerCase();
    }

    function dispatchChangeEvent(libraryId, active) {
        try {
            window.dispatchEvent(new CustomEvent('library:changed', {
                detail: { libraryId: libraryId, active: active }
            }));
        } catch (e) {
            // Ignorar errores de eventos
        }
    }

    // === PUBLIC ===

    function init() {
        loadFromStorage();
        var count = Object.keys(libraries).length;
        console.log('[ColorLibraryManager] Inicializado: ' + count + ' bibliotecas, activa: ' + (activeId || 'ninguna'));
        return { libraries: count, active: activeId };
    }

    function load(name, colors) {
        var id = generateId();
        var colorMap = {};

        for (var key in colors) {
            if (colors.hasOwnProperty(key)) {
                var normalized = normalizeName(key);
                if (normalized) {
                    colorMap[normalized] = {
                        originalName: key,
                        hex: colors[key].hex || '#000000',
                        rgb: colors[key].rgb || null,
                        cmyk: colors[key].cmyk || null
                    };
                }
            }
        }

        libraries[id] = {
            id: id,
            name: name || 'Biblioteca sin nombre',
            colors: colorMap,
            importedAt: Date.now(),
            colorCount: Object.keys(colorMap).length
        };

        saveToStorage();
        console.log('[ColorLibraryManager] Biblioteca "' + name + '" cargada: ' + Object.keys(colorMap).length + ' colores');

        // Si no hay biblioteca activa, activar esta
        if (!activeId) {
            activate(id);
        }

        dispatchChangeEvent(id, true);

        return id;
    }

    function activate(id) {
        if (!libraries[id]) {
            console.warn('[ColorLibraryManager] Biblioteca ' + id + ' no encontrada');
            return false;
        }
        activeId = id;
        saveToStorage();
        console.log('[ColorLibraryManager] Biblioteca activada: "' + libraries[id].name + '"');
        dispatchChangeEvent(id, true);
        return true;
    }

    function deactivate() {
        activeId = null;
        saveToStorage();
        console.log('[ColorLibraryManager] Biblioteca desactivada');
        dispatchChangeEvent(null, false);
        return true;
    }

    function resolve(name) {
        if (!activeId) return null;
        var lib = libraries[activeId];
        if (!lib) return null;

        var normalized = normalizeName(name);
        if (!normalized) return null;

        var match = lib.colors[normalized];
        if (!match) return null;

        return {
            found: true,
            hex: match.hex,
            rgb: match.rgb,
            cmyk: match.cmyk,
            originalName: match.originalName,
            libraryName: lib.name,
            libraryId: activeId
        };
    }

    function getActive() {
        if (!activeId) return null;
        return libraries[activeId] || null;
    }

    function getAll() {
        var result = [];
        for (var id in libraries) {
            if (libraries.hasOwnProperty(id)) {
                result.push(libraries[id]);
            }
        }
        return result;
    }

    function deleteLibrary(id) {
        if (!libraries[id]) return false;
        delete libraries[id];
        if (activeId === id) {
            activeId = null;
        }
        saveToStorage();
        dispatchChangeEvent(activeId, !!activeId);
        return true;
    }

    function exportActive() {
        var lib = getActive();
        if (!lib) return null;

        var colors = {};
        for (var normalized in lib.colors) {
            if (lib.colors.hasOwnProperty(normalized)) {
                var data = lib.colors[normalized];
                colors[data.originalName || normalized] = {
                    hex: data.hex,
                    rgb: data.rgb,
                    cmyk: data.cmyk
                };
            }
        }

        return {
            name: lib.name,
            colors: colors,
            colorCount: Object.keys(colors).length
        };
    }

    function getStats() {
        var lib = getActive();
        if (!lib) return { active: false };
        return {
            active: true,
            name: lib.name,
            colorCount: lib.colorCount,
            id: lib.id,
            importedAt: lib.importedAt
        };
    }

    // === INIT ===
    loadFromStorage();

    // === PUBLIC API ===
    return {
        init: init,
        load: load,
        activate: activate,
        deactivate: deactivate,
        resolve: resolve,
        getActive: getActive,
        getAll: getAll,
        delete: deleteLibrary,
        exportActive: exportActive,
        getStats: getStats
    };
})();