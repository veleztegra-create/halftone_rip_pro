// ============================================================
// HALFTONE RIP PRO - Preview & Differences Module
// Maneja: visualización de separaciones, composición, diffs
// ============================================================

const PreviewModule = (function() {
    'use strict';

    // === STATE ===
    let lastJobName = null;
    let separationImages = [];
    let viewMode = 'individual';
    let compositeMode = 'overprint';
    let refImageData = null;
    let layerSettings = [];
    let // loadedImages se inicializa solo en loadSeparationsPreview, no aquí
    let isAnalyzing = false;

    // === DOM CACHE ===
    const $ = (id) => document.getElementById(id);
    const $$ = (sel) => document.querySelectorAll(sel);

    // === INITIALIZATION ===
    function init() {
        bindEvents();
        bindRipEvents();
        initCrossfadeControl();
        initAseUI();
        logPreview('🎨 Módulo Preview inicializado', 'success');
    }

    function bindEvents() {
        // View mode tabs: se usa el atributo data-mode de cada botón
        const viewTabs = $$('.view-tab');
        viewTabs.forEach((tab) => {
            tab.onclick = () => setViewMode(tab.dataset.mode);
        });

        // Composite mode buttons
        const modeBtns = $$('.mode-btn');
        modeBtns.forEach(btn => {
            btn.onclick = () => setCompositeMode(btn.dataset.mode);
        });

        // Reference image
        const refDrop = $('ref-drop');
        const refInput = $('ref-input');

        if (refDrop) {
            refDrop.onclick = (e) => {
                if (e.target.tagName !== 'INPUT') refInput?.click();
            };
            refDrop.addEventListener('dragover', (e) => {
                e.preventDefault();
                refDrop.style.borderColor = 'var(--accent-primary)';
            });
            refDrop.addEventListener('dragleave', () => {
                refDrop.style.borderColor = '';
            });
            refDrop.addEventListener('drop', onRefDrop);
        }

        if (refInput) refInput.onchange = (e) => {
            if (e.target.files[0]) loadRefFile(e.target.files[0]);
        };

        if ($('btn-demo-ref')) $('btn-demo-ref').onclick = loadDemoRef;
        if ($('btn-clear-ref')) $('btn-clear-ref').onclick = clearRef;
        if ($('diff-opacity')) $('diff-opacity').oninput = updateDiffOpacity;
        if ($('analyze-btn')) $('analyze-btn').onclick = runAnalysis;

        if ($('composite-bg-color')) {
            $('composite-bg-color').addEventListener('input', () => {
                if (viewMode === 'composite') renderComposite();
            });
        }

        // Tab switch listener
        const tabPreview = $('tab-preview');
        if (tabPreview) {
            tabPreview.addEventListener('click', () => {
                if (lastJobName) loadSeparationsPreview();
            });
        }

        // Escuchar evento de tab activado para cargar separaciones si es necesario
        window.addEventListener('preview:tabActivated', function() {
            if (lastJobName && !document.querySelector('#separations-container .sep-thumb')) {
                loadSeparationsPreview();
            }
        });
    }

    function bindRipEvents() {
        window.addEventListener('rip:jobComplete', (e) => {
            lastJobName = e.detail.jobName;
            logPreview('✅ Trabajo recibido: ' + lastJobName, 'success');
            // Auto-switch to preview tab after a delay
            setTimeout(() => {
                const tabPreview = $('tab-preview');
                if (tabPreview) tabPreview.click();
            }, 800);
        });
    }

    // === SEPARATIONS LOADING ===
    function loadSeparationsPreview() {
        if (!lastJobName) {
            showEmptyState('Procesa un archivo primero para ver las separaciones');
            return;
        }

        logPreview('Cargando separaciones...');

        fetch('/api/separation_info', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ job_name: lastJobName })
        })
        .then(r => r.json())
        .then(data => {
            if (data.error) throw new Error(data.error);

            separationImages = data.separations || [];
            updateStats();

            // Initialize layer settings
            layerSettings = separationImages.map((sep, idx) => ({
                name: sep.name,
                filename: sep.filename,
                visible: true,
                opacity: 1,
                color: sep.hex_color,
                is_cmyk: sep.is_cmyk,
                order: idx
            }));

            renderPreviewByMode();
            logPreview('✅ ' + separationImages.length + ' separaciones cargadas', 'success');

            // Actualizar UI de ASE si existe
            if (window.__aseUI && window.__aseUI.renderLibrarySelector) {
                window.__aseUI.renderLibrarySelector();
            }
        })
        .catch(err => {
            logPreview('❌ Error cargando separaciones: ' + err.message, 'error');
            showEmptyState('Error cargando separaciones. Intenta de nuevo.');
        });
    }

    function updateStats() {
        const cmykCount = separationImages.filter(s => s.is_cmyk).length;
        const spotCount = separationImages.filter(s => !s.is_cmyk).length;

        if ($('stat-sep-count')) $('stat-sep-count').textContent = separationImages.length;
        if ($('stat-cmyk-count')) $('stat-cmyk-count').textContent = cmykCount;
        if ($('stat-spot-count')) $('stat-spot-count').textContent = spotCount;
    }

    function showEmptyState(msg) {
        const container = $('separations-container');
        if (container) {
            container.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:3rem;color:var(--text-muted);font-family:var(--font-mono);font-size:0.8rem;">' + msg + '</div>';
        }
    }

    // === VIEW MODES ===
    function setViewMode(mode) {
        viewMode = mode;
        document.querySelectorAll('.view-tab').forEach((btn) => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });
        renderPreviewByMode();
    }

    function setCompositeMode(mode) {
        compositeMode = mode;
        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });
        if (viewMode === 'composite') renderComposite();
    }

    function renderPreviewByMode() {
        const container = $('separations-container');
        const compositeDiv = $('composite-container');
        if (!container || !compositeDiv) return;

        if (viewMode === 'composite') {
            container.style.display = 'none';
            compositeDiv.style.display = 'block';
            renderLayersList();
            renderComposite();
            return;
        }

        container.style.display = 'grid';
        compositeDiv.style.display = 'none';

        if (separationImages.length === 0) {
            showEmptyState('Procesa un archivo primero para ver las separaciones');
            return;
        }

        if (viewMode === 'individual') {
            renderIndividualSeparations(container);
        }
    }

    function renderIndividualSeparations(container) {
        container.innerHTML = separationImages.map(function(sep, idx) {
            return '<div class="sep-thumb animate-fade-in" style="animation-delay:' + (idx * 0.03) + 's">' +
                '<div class="sep-thumb-img" id="sep-bg-' + sep.filename + '" style="background-color: transparent; transition: background-color 0.3s; display: flex; justify-content: center; align-items: center; overflow: hidden;">' +
                    '<img id="sep-img-' + sep.filename + '" src="/api/download/' + lastJobName + '/' + sep.filename + '" alt="' + sep.name + '" loading="lazy" style="mix-blend-mode: normal; transition: mix-blend-mode 0.3s;" ondblclick="PreviewModule.openFullscreen(this.src)">' +
                '</div>' +
                '<div class="sep-thumb-info">' +
                    '<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">' +
                        '<div class="sep-thumb-color" style="background:' + sep.hex_color + '" onclick="PreviewModule.openColorPicker(\'' + sep.filename + '\', \'' + sep.hex_color + '\')" title="' + (sep.is_cmyk ? '' : 'Color de referencia (no el Pantone exacto) - haz clic para corregirlo al color real') + '"></div>' +
                        '<span class="sep-thumb-name">' + sep.name + '</span>' +
                    '</div>' +
                    '<span class="sep-thumb-badge" style="background:' + (sep.is_cmyk ? 'var(--accent-primary)' : 'var(--accent-secondary)') + '">' + (sep.is_cmyk ? 'CMYK' : 'SPOT') + '</span>' +
                    '<div class="sep-thumb-size">' + sep.size[0] + ' x ' + sep.size[1] + ' px</div>' +
                    '<div style="display:flex;align-items:center;gap:4px;margin-top:4px;">' +
                        (!sep.is_cmyk ? '<input type="color" class="color-picker-input" value="' + sep.hex_color + '" onchange="PreviewModule.updateSepColor(\'' + sep.filename + '\', this.value)" style="width: 24px; height: 24px; padding: 0; border: none; cursor: pointer;">' : '') +
                        '<input type="text" class="form-input" value="' + sep.hex_color + '" onchange="PreviewModule.updateSepColor(\'' + sep.filename + '\', this.value)" style="padding: 2px 6px; font-size: 0.75rem; width: 70px; font-family: var(--font-mono); text-align: center;" placeholder="#HEX o nombre" title="Podés escribir un hex (#0066CC) o un nombre de color como \'azul claro\'">' +
                        '<button onclick="PreviewModule.toggleColorize(\'' + sep.filename + '\')" class="btn-secondary" style="padding: 2px 6px; font-size: 0.7rem; border-radius: 4px; border: 1px solid var(--border-medium); background: var(--bg-tertiary); color: var(--text-primary); cursor: pointer; display: flex; align-items: center; gap: 4px;" title="Alternar previsualización de color"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/></svg> Color</button>' +
                    '</div>' +
                '</div>' +
            '</div>';
        }).join('');
    }

    function renderColoredSeparations(container) {
        container.innerHTML = separationImages.map(function(sep, idx) {
            return '<div class="sep-thumb animate-fade-in" style="animation-delay:' + (idx * 0.03) + 's">' +
                '<div class="sep-thumb-img">' +
                    '<img src="/api/separation_preview/' + lastJobName + '/' + sep.filename + '" alt="' + sep.name + '" loading="lazy">' +
                '</div>' +
                '<div class="sep-thumb-info">' +
                    '<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">' +
                        '<div class="sep-thumb-color" style="background:' + sep.hex_color + '"></div>' +
                        '<span class="sep-thumb-name">' + sep.name + '</span>' +
                    '</div>' +
                    '<div style="font-size:0.6rem;color:var(--text-muted);font-family:var(--font-mono);text-align:center;padding:4px;background:var(--bg-deep);border-radius:4px;">' + sep.hex_color + '</div>' +
                '</div>' +
            '</div>';
        }).join('');
    }

    // === COMPOSITE RENDERING ===
    function renderComposite() {
        const canvas = $('composite-canvas');
        if (!canvas || !layerSettings.length) return;

        // Load all images
        // loadedImages se inicializa solo en loadSeparationsPreview, no aquí
        var loadPromises = layerSettings.map(function(layer) {
            return new Promise(function(resolve, reject) {
                if (loadedImages[layer.filename]) {
                    resolve(loadedImages[layer.filename]);
                    return;
                }
                fetch('/api/download/' + lastJobName + '/' + layer.filename)
                    .then(function(r) { return r.blob(); })
                    .then(function(blob) {
                        var img = new Image();
                        img.onload = function() {
                            loadedImages[layer.filename] = img;
                            resolve(img);
                        };
                        img.onerror = reject;
                        img.src = URL.createObjectURL(blob);
                    })
                    .catch(reject);
            });
        });

        Promise.all(loadPromises).then(function() {
            var firstImg = loadedImages[layerSettings[0]?.filename];
            if (!firstImg) return;

            // Scale down for preview if image is too large to prevent browser crash
            var MAX_DIM = 1200;
            var scale = 1;
            if (firstImg.width > MAX_DIM || firstImg.height > MAX_DIM) {
                scale = Math.min(MAX_DIM / firstImg.width, MAX_DIM / firstImg.height);
            }

            canvas.width = Math.floor(firstImg.width * scale);
            canvas.height = Math.floor(firstImg.height * scale);
            var ctx = canvas.getContext('2d', { willReadFrequently: true });

            // Garment Background
            var bgColor = document.getElementById('composite-bg-color') ? document.getElementById('composite-bg-color').value : '#ffffff';
            ctx.fillStyle = bgColor;
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            var sortedLayers = layerSettings.slice().sort(function(a, b) { return a.order - b.order; });

            for (var li = 0; li < sortedLayers.length; li++) {
                var layer = sortedLayers[li];
                if (!layer.visible) continue;
                var img = loadedImages[layer.filename];
                if (!img) continue;

                var tempCanvas = document.createElement('canvas');
                tempCanvas.width = canvas.width;
                tempCanvas.height = canvas.height;
                var tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });

                tempCtx.drawImage(img, 0, 0, canvas.width, canvas.height);

                var imageData = tempCtx.getImageData(0, 0, canvas.width, canvas.height);
                var pixels = imageData.data;
                var color = hexToRgb(layer.color);

                for (var i = 0; i < pixels.length; i += 4) {
                    var inkIntensity = (255 - pixels[i]) / 255;
                    if (inkIntensity > 0.05) {
                        var alpha = inkIntensity * layer.opacity;
                        pixels[i] = color.r;
                        pixels[i + 1] = color.g;
                        pixels[i + 2] = color.b;
                        pixels[i + 3] = Math.floor(alpha * 255);
                    } else {
                        pixels[i + 3] = 0;
                    }
                }
                tempCtx.putImageData(imageData, 0, 0);

                var op = 'source-over';
                if (compositeMode === 'overprint') {
                    op = layer.is_cmyk ? 'multiply' : 'source-over';
                    if (color.r > 220 && color.g > 220 && color.b > 220) {
                        op = 'source-over';
                    }
                }
                ctx.globalCompositeOperation = op;
                ctx.drawImage(tempCanvas, 0, 0);
            }

            canvas.style.maxWidth = '100%';
            canvas.style.height = 'auto';
            canvas.style.display = 'block';

            var activeCount = layerSettings.filter(function(l) { return l.visible; }).length;
            if ($('stat-total-coverage')) $('stat-total-coverage').textContent = activeCount;
            if ($('composite-mode-label')) $('composite-mode-label').textContent = compositeMode.toUpperCase();
        }).catch(function(err) {
            console.warn('Error cargando imágenes para composición:', err);
        });
    }

    function renderLayersList() {
        var container = $('layers-list');
        if (!container) return;

        var sorted = layerSettings.slice().sort(function(a, b) { return a.order - b.order; });
        container.innerHTML = '';

        for (var i = 0; i < sorted.length; i++) {
            var layer = sorted[i];
            var div = document.createElement('div');
            div.className = 'layer-item';
            div.draggable = true;
            div.dataset.filename = layer.filename;

            div.innerHTML =
                '<span class="drag-handle">⋮⋮</span>' +
                '<div class="layer-color-badge" style="background:' + layer.color + '" onclick="PreviewModule.openColorPicker(\'' + layer.filename + '\', \'' + layer.color + '\')"></div>' +
                '<span class="layer-name" title="' + layer.name + '">' + layer.name.substring(0, 22) + '</span>' +
                '<span class="layer-eye" style="opacity: ' + (layer.visible ? '1' : '0.3') + '; cursor: pointer;" onclick="PreviewModule.toggleLayer(\'' + layer.filename + '\')">' + (layer.visible ? '👁' : '👁‍🗨') + '</span>' +
                '<input type="range" class="layer-opacity" min="0" max="100" value="' + (layer.opacity * 100) + '" oninput="PreviewModule.changeOpacity(\'' + layer.filename + '\', this.value)">' +
                '<span class="opacity-value">' + Math.round(layer.opacity * 100) + '%</span>';

            div.addEventListener('dragstart', function(e) {
                e.dataTransfer.setData('text/plain', layer.filename);
                div.classList.add('dragging');
            });
            div.addEventListener('dragend', function() { div.classList.remove('dragging'); });
            div.addEventListener('dragover', function(e) {
                e.preventDefault();
                div.classList.add('drag-over');
            });
            div.addEventListener('dragleave', function() { div.classList.remove('drag-over'); });
            div.addEventListener('drop', function(e) {
                e.preventDefault();
                div.classList.remove('drag-over');
                var fromFile = e.dataTransfer.getData('text/plain');
                var toFile = layer.filename;
                if (fromFile === toFile) return;

                var ordered = layerSettings.slice().sort(function(a, b) { return a.order - b.order; });
                var fromPos = -1;
                var toPos = -1;
                for (var j = 0; j < ordered.length; j++) {
                    if (ordered[j].filename === fromFile) fromPos = j;
                    if (ordered[j].filename === toFile) toPos = j;
                }
                if (fromPos === -1 || toPos === -1) return;

                var moved = ordered.splice(fromPos, 1)[0];
                ordered.splice(toPos, 0, moved);

                for (var k = 0; k < ordered.length; k++) {
                    var target = null;
                    for (var l = 0; l < layerSettings.length; l++) {
                        if (layerSettings[l].filename === ordered[k].filename) {
                            target = layerSettings[l];
                            break;
                        }
                    }
                    if (target) target.order = k;
                }

                renderLayersList();
                renderComposite();
            });

            container.appendChild(div);
        }
    }

    // === COLOR PICKER ===
    function openColorPicker(filename, currentColor) {
        var input = document.createElement('input');
        input.type = 'color';
        input.value = currentColor;
        input.addEventListener('change', function(e) {
            updateSepColor(filename, e.target.value);
        });
        input.click();
    }

    function toggleColorize(filename) {
        var bg = document.getElementById('sep-bg-' + filename);
        var img = document.getElementById('sep-img-' + filename);
        var layer = null;
        for (var i = 0; i < layerSettings.length; i++) {
            if (layerSettings[i].filename === filename) {
                layer = layerSettings[i];
                break;
            }
        }
        if (!bg || !img || !layer) return;

        if (bg.dataset.colorized === "true") {
            bg.dataset.colorized = "false";
            bg.style.backgroundColor = 'transparent';
            img.style.mixBlendMode = 'normal';
        } else {
            bg.dataset.colorized = "true";
            bg.style.backgroundColor = layer.color;
            img.style.mixBlendMode = 'screen';
        }
    }

    function resolveColorInput(value) {
        var trimmed = (value || '').trim();
        if (/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(trimmed)) {
            return trimmed;
        }

        if (typeof KnowledgeEngine === 'undefined') {
            return trimmed;
        }

        var info = KnowledgeEngine.resolve(trimmed);
        if (info.displayColor) {
            if (info.warnings && info.warnings.length) {
                var logType = info.confidence === 0 ? 'warn' : 'info';
                info.warnings.forEach(function(w) { logPreview('Color: ' + w, logType); });
            }
            return info.displayColor;
        }

        return trimmed;
    }

    function updateSepColor(filename, newColor) {
        var resolvedColor = resolveColorInput(newColor);

        for (var i = 0; i < separationImages.length; i++) {
            if (separationImages[i].filename === filename) {
                separationImages[i].hex_color = resolvedColor;
                break;
            }
        }

        for (var j = 0; j < layerSettings.length; j++) {
            if (layerSettings[j].filename === filename) {
                layerSettings[j].color = resolvedColor;
                break;
            }
        }

        var bg = document.getElementById('sep-bg-' + filename);
        if (bg && bg.dataset.colorized === "true") {
            bg.style.backgroundColor = resolvedColor;
        }

        renderPreviewByMode();
        if (viewMode === 'composite') {
            renderLayersList();
            renderComposite();
        }
    }

    function toggleLayer(filename) {
        for (var i = 0; i < layerSettings.length; i++) {
            if (layerSettings[i].filename === filename) {
                layerSettings[i].visible = !layerSettings[i].visible;
                break;
            }
        }
        renderLayersList();
        renderComposite();
    }

    function changeOpacity(filename, value) {
        for (var i = 0; i < layerSettings.length; i++) {
            if (layerSettings[i].filename === filename) {
                layerSettings[i].opacity = value / 100;
                break;
            }
        }
        renderLayersList();
        renderComposite();
    }

    // === FULLSCREEN IMAGE VIEWER ===
    function openFullscreen(src) {
        var overlay = document.createElement('div');
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100vw';
        overlay.style.height = '100vh';
        overlay.style.backgroundColor = 'rgba(0,0,0,0.9)';
        overlay.style.zIndex = '9999';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.style.overflow = 'auto';
        overlay.style.cursor = 'zoom-out';
        overlay.className = 'fullscreen-overlay';

        var img = document.createElement('img');
        img.src = src;
        img.style.maxWidth = '90%';
        img.style.maxHeight = '90%';
        img.style.objectFit = 'contain';
        img.style.transition = 'transform 0.2s ease';
        img.style.cursor = 'zoom-in';

        var scale = 1;
        var isDragging = false;
        var startX, startY, translateX = 0, translateY = 0;

        function updateTransform() {
            img.style.transform = 'translate(' + translateX + 'px, ' + translateY + 'px) scale(' + scale + ')';
        }

        overlay.addEventListener('wheel', function(e) {
            e.preventDefault();
            var zoomAmount = 0.15;
            if (e.deltaY < 0) {
                scale += zoomAmount;
            } else {
                scale -= zoomAmount;
                if (scale < 0.1) scale = 0.1;
            }
            updateTransform();
        });

        img.addEventListener('mousedown', function(e) {
            e.preventDefault();
            isDragging = true;
            startX = e.clientX - translateX;
            startY = e.clientY - translateY;
            img.style.cursor = 'grabbing';
        });

        overlay.addEventListener('mousemove', function(e) {
            if (!isDragging) return;
            e.preventDefault();
            translateX = e.clientX - startX;
            translateY = e.clientY - startY;
            updateTransform();
        });

        overlay.addEventListener('mouseup', function() {
            isDragging = false;
            img.style.cursor = 'zoom-in';
        });

        overlay.addEventListener('mouseleave', function() {
            isDragging = false;
            img.style.cursor = 'zoom-in';
        });

        img.onclick = function(e) {
            e.stopPropagation();
            if (scale !== 1 || translateX !== 0 || translateY !== 0) {
                scale = 1;
                translateX = 0;
                translateY = 0;
                updateTransform();
            } else {
                scale = 2;
                updateTransform();
            }
        };

        overlay.onclick = function(e) {
            if (e.target === overlay) {
                document.body.removeChild(overlay);
            }
        };

        overlay.appendChild(img);
        document.body.appendChild(overlay);
    }

    // === REFERENCE IMAGE ===
    function onRefDrop(e) {
        e.preventDefault();
        var refDrop = $('ref-drop');
        if (refDrop) refDrop.style.borderColor = '';

        var file = e.dataTransfer.files[0];
        if (file) loadRefFile(file);
    }

    function loadRefFile(file) {
        var validExts = ['jpg', 'jpeg', 'png', 'tiff', 'tif', 'webp', 'gif', 'bmp'];
        var ext = file.name.split('.').pop().toLowerCase();

        if (validExts.indexOf(ext) === -1) {
            alert('Formato no soportado: ' + ext);
            return;
        }

        var reader = new FileReader();
        reader.onload = function(ev) { showRefCanvas(ev.target.result); };
        reader.onerror = function() { logPreview('Error leyendo archivo', 'error'); };
        reader.readAsDataURL(file);
    }

    function loadDemoRef() {
        var canvas = document.createElement('canvas');
        canvas.width = 400;
        canvas.height = 340;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, 400, 340);

        var colors = ['#00d4ff', '#ff4d8a', '#ffd166', '#888888'];
        colors.forEach(function(col, i) {
            ctx.globalAlpha = 0.6;
            ctx.fillStyle = col;
            for (var j = 0; j < 8; j++) {
                var x = ((i * 97 + j * 53) % 360) + 20;
                var y = ((i * 61 + j * 79) % 280) + 30;
                var r = 10 + ((i * 7 + j * 13) % 25);
                ctx.beginPath();
                ctx.arc(x, y, r, 0, Math.PI * 2);
                ctx.fill();
            }
        });
        ctx.globalAlpha = 1;
        showRefCanvas(canvas.toDataURL());
    }

    // === REFERENCIA & COMPARACIÓN ===

    function loadSeparationBase() {
        if (!lastJobName) return;
        var baseImg = $('align-base-img');
        if (!baseImg) return;
        fetch('/api/composite_visual', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ job_name: lastJobName, mode: 'overprint' })
        })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.composite) {
                baseImg.src = data.composite;
                baseImg.style.opacity = 0.5;
                baseImg.onload = function() { positionHandles(); };
            }
        })
        .catch(function(e) {
            console.warn('No se pudo cargar el compuesto de separaciones:', e);
        });
    }

    function updateCrossfade() {
        var val = parseInt($('crossfade-slider')?.value ?? 50, 10);
        var refImg = $('ref-preview-img');
        var baseImg = $('align-base-img');
        if (refImg) refImg.style.opacity = (100 - val) / 100;
        if (baseImg) baseImg.style.opacity = val / 100;
    }

    function getAlignValues() {
        return {
            scale: parseFloat($('align-scale')?.value || 100) / 100,
            x: parseFloat($('align-x')?.value || 0),
            y: parseFloat($('align-y')?.value || 0)
        };
    }

    function updateRefTransform(source) {
        if (source === 'scale-num' && $('align-scale-num')) {
            $('align-scale').value = $('align-scale-num').value;
        } else if (source === 'scale-range' && $('align-scale-num')) {
            $('align-scale-num').value = $('align-scale').value;
        }
        if (source === 'x-num' && $('align-x-num')) {
            $('align-x').value = $('align-x-num').value;
        } else if (source === 'x-range' && $('align-x-num')) {
            $('align-x-num').value = $('align-x').value;
        }
        if (source === 'y-num' && $('align-y-num')) {
            $('align-y').value = $('align-y-num').value;
        } else if (source === 'y-range' && $('align-y-num')) {
            $('align-y-num').value = $('align-y').value;
        }

        var v = getAlignValues();
        var refImg = $('ref-preview-img');
        if (refImg) {
            refImg.style.transform = 'translate(' + v.x + 'px, ' + v.y + 'px) scale(' + v.scale + ')';
        }
        positionHandles();
    }

    var HANDLE_CORNERS = ['tl', 'tr', 'bl', 'br'];
    var handleDrag = null;

    function setAlignValues(scale, x, y) {
        var clamp = function(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); };
        var s = clamp(Math.round(scale * 100), 5, 800);
        var xi = clamp(Math.round(x), -5000, 5000);
        var yi = clamp(Math.round(y), -5000, 5000);
        if ($('align-scale')) $('align-scale').value = s;
        if ($('align-scale-num')) $('align-scale-num').value = s;
        if ($('align-x')) $('align-x').value = xi;
        if ($('align-x-num')) $('align-x-num').value = xi;
        if ($('align-y')) $('align-y').value = yi;
        if ($('align-y-num')) $('align-y-num').value = yi;
        updateRefTransform(null);
    }

    function initAlignHandles() {
        var container = $('align-container');
        var refImg = $('ref-preview-img');
        if (!container || !refImg) return;

        refImg.classList.add('align-editable');
        refImg.onpointerdown = function(e) { startBodyDrag(e); };

        HANDLE_CORNERS.forEach(function(corner) {
            var handle = document.getElementById('align-handle-' + corner);
            if (!handle) {
                handle = document.createElement('div');
                handle.id = 'align-handle-' + corner;
                handle.className = 'align-handle handle-' + corner;
                container.appendChild(handle);
            }
            handle.onpointerdown = function(e) { startCornerDrag(e, corner); };
        });

        positionHandles();
    }

    function destroyAlignHandles() {
        HANDLE_CORNERS.forEach(function(corner) {
            var handle = document.getElementById('align-handle-' + corner);
            if (handle) handle.remove();
        });
        var refImg = $('ref-preview-img');
        if (refImg) refImg.classList.remove('align-editable');
    }

    function positionHandles() {
        var container = $('align-container');
        var refImg = $('ref-preview-img');
        if (!container || !refImg || !refImg.naturalWidth) return;
        var hasHandles = false;
        for (var i = 0; i < HANDLE_CORNERS.length; i++) {
            if (document.getElementById('align-handle-' + HANDLE_CORNERS[i])) {
                hasHandles = true;
                break;
            }
        }
        if (!hasHandles) return;

        var v = getAlignValues();
        var w0 = container.clientWidth;
        var h0 = w0 * (refImg.naturalHeight / refImg.naturalWidth);

        var corners = {
            tl: [v.x, v.y],
            tr: [v.x + w0 * v.scale, v.y],
            bl: [v.x, v.y + h0 * v.scale],
            br: [v.x + w0 * v.scale, v.y + h0 * v.scale]
        };
        HANDLE_CORNERS.forEach(function(corner) {
            var handle = document.getElementById('align-handle-' + corner);
            if (!handle) return;
            handle.style.left = corners[corner][0] + 'px';
            handle.style.top = corners[corner][1] + 'px';
        });
    }

    function startBodyDrag(e) {
        e.preventDefault();
        var v0 = getAlignValues();
        var startX = e.clientX, startY = e.clientY;
        handleDrag = { type: 'move', v0: v0, startX: startX, startY: startY };
        document.addEventListener('pointermove', onHandleDragMove);
        document.addEventListener('pointerup', onHandleDragEnd, { once: true });
    }

    function startCornerDrag(e, corner) {
        e.preventDefault();
        e.stopPropagation();
        var container = $('align-container');
        var refImg = $('ref-preview-img');
        if (!container || !refImg) return;

        var v0 = getAlignValues();
        var rect = container.getBoundingClientRect();
        var w0 = container.clientWidth;
        var h0 = w0 * (refImg.naturalHeight / refImg.naturalWidth);

        var oppositeLocal = {
            tl: [w0, h0], tr: [0, h0], bl: [w0, 0], br: [0, 0]
        }[corner];
        var draggedLocal = {
            tl: [0, 0], tr: [w0, 0], bl: [0, h0], br: [w0, h0]
        }[corner];

        var anchor = [
            v0.x + oppositeLocal[0] * v0.scale,
            v0.y + oppositeLocal[1] * v0.scale
        ];
        var startCornerScreen = [
            v0.x + draggedLocal[0] * v0.scale,
            v0.y + draggedLocal[1] * v0.scale
        ];
        var dist0 = Math.hypot(startCornerScreen[0] - anchor[0], startCornerScreen[1] - anchor[1]) || 1;

        handleDrag = { type: 'resize', v0: v0, rect: rect, anchor: anchor, oppositeLocal: oppositeLocal, dist0: dist0 };
        document.addEventListener('pointermove', onHandleDragMove);
        document.addEventListener('pointerup', onHandleDragEnd, { once: true });
    }

    function onHandleDragMove(e) {
        if (!handleDrag) return;

        if (handleDrag.type === 'move') {
            var dx = e.clientX - handleDrag.startX;
            var dy = e.clientY - handleDrag.startY;
            setAlignValues(handleDrag.v0.scale, handleDrag.v0.x + dx, handleDrag.v0.y + dy);
            return;
        }

        var v0 = handleDrag.v0;
        var rect = handleDrag.rect;
        var anchor = handleDrag.anchor;
        var oppositeLocal = handleDrag.oppositeLocal;
        var dist0 = handleDrag.dist0;
        var mouseX = e.clientX - rect.left;
        var mouseY = e.clientY - rect.top;
        var distNow = Math.hypot(mouseX - anchor[0], mouseY - anchor[1]) || 0;

        var newScale = v0.scale * (distNow / dist0);
        newScale = Math.min(8.0, Math.max(0.05, newScale));

        var newX = anchor[0] - oppositeLocal[0] * newScale;
        var newY = anchor[1] - oppositeLocal[1] * newScale;
        setAlignValues(newScale, newX, newY);
    }

    function onHandleDragEnd() {
        document.removeEventListener('pointermove', onHandleDragMove);
        handleDrag = null;
    }

    function initCrossfadeControl() {
        if ($('crossfade-slider')) $('crossfade-slider').oninput = updateCrossfade;
        if ($('auto-align-btn')) $('auto-align-btn').onclick = runAutoAlign;
        if ($('align-scale')) $('align-scale').oninput = function() { updateRefTransform('scale-range'); };
        if ($('align-x')) $('align-x').oninput = function() { updateRefTransform('x-range'); };
        if ($('align-y')) $('align-y').oninput = function() { updateRefTransform('y-range'); };

        if ($('edge-tolerance') && $('edge-tolerance-num')) {
            $('edge-tolerance').oninput = function() { $('edge-tolerance-num').value = $('edge-tolerance').value; };
            $('edge-tolerance-num').oninput = function() { $('edge-tolerance').value = $('edge-tolerance-num').value; };
        }
        if ($('align-scale-num')) $('align-scale-num').oninput = function() { updateRefTransform('scale-num'); };
        if ($('align-x-num')) $('align-x-num').oninput = function() { updateRefTransform('x-num'); };
        if ($('align-y-num')) $('align-y-num').oninput = function() { updateRefTransform('y-num'); };
    }

    async function runAutoAlign() {
        if (!refImageData || !lastJobName) {
            alert('Se necesita un trabajo procesado y una imagen de referencia');
            return;
        }
        var btn = $('auto-align-btn');
        var statusEl = $('auto-align-status');
        if (btn) { btn.disabled = true; btn.textContent = '⏳ Calculando...'; }

        try {
            var resp = await fetch('/api/auto_align', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ job_name: lastJobName, reference: refImageData })
            });
            var data = await resp.json();
            if (data.error) throw new Error(data.error);

            var baseImg = $('align-base-img');
            var displayRatio = (baseImg && baseImg.clientWidth > 0 && baseImg.naturalWidth > 0)
                ? baseImg.naturalWidth / baseImg.clientWidth : 1;

            var clamp = function(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); };
            var scalePct = clamp(Math.round(data.scale * 100), 5, 800);
            var xSlider = clamp(Math.round(data.offset_x / displayRatio), -5000, 5000);
            var ySlider = clamp(Math.round(data.offset_y / displayRatio), -5000, 5000);

            if ($('align-scale')) $('align-scale').value = scalePct;
            if ($('align-scale-num')) $('align-scale-num').value = scalePct;
            if ($('align-x')) $('align-x').value = xSlider;
            if ($('align-x-num')) $('align-x-num').value = xSlider;
            if ($('align-y')) $('align-y').value = ySlider;
            if ($('align-y-num')) $('align-y-num').value = ySlider;

            updateRefTransform(null);

            var pct = Math.round(data.confidence * 100);
            if (statusEl) {
                statusEl.style.display = 'block';
                if (data.confidence < 0.35) {
                    statusEl.style.color = '#e05555';
                    statusEl.textContent = '⚠️ Confianza baja (' + pct + '%). El arte de referencia puede ser muy distinto a la separación — revisa o ajusta a mano.';
                } else {
                    statusEl.style.color = 'var(--text-muted)';
                    statusEl.textContent = '✅ Auto-alineado (confianza ' + pct + '%). Puedes afinar a mano si hace falta.';
                }
            }
            logPreview('🎯 Auto-alineado: escala ' + scalePct + '%, confianza ' + pct + '%', 'success');
        } catch (e) {
            logPreview('❌ Error en auto-alineado: ' + e.message, 'error');
            alert('No se pudo auto-alinear: ' + e.message);
        } finally {
            if (btn) { btn.disabled = false; btn.textContent = '🎯 Auto-alinear'; }
        }
    }

    function showRefCanvas(dataUrl) {
        var img = $('ref-preview-img');
        if (!img) return;

        img.onload = function() {
            if ($('ref-drop')) $('ref-drop').style.display = 'none';
            if ($('ref-canvas-wrap')) $('ref-canvas-wrap').style.display = 'block';
            if ($('crossfade-ctrl')) $('crossfade-ctrl').style.display = 'flex';
            if ($('alignment-ctrl')) $('alignment-ctrl').style.display = 'flex';
            if ($('btn-clear-ref')) $('btn-clear-ref').style.display = 'block';
            if ($('no-ref-msg')) $('no-ref-msg').style.display = 'none';
            if ($('analyze-btn')) $('analyze-btn').disabled = !lastJobName;
            if ($('diff-results')) $('diff-results').innerHTML = '';

            if ($('crossfade-slider')) $('crossfade-slider').value = 50;
            if ($('align-scale')) $('align-scale').value = 100;
            if ($('align-scale-num')) $('align-scale-num').value = 100;
            if ($('align-x')) $('align-x').value = 0;
            if ($('align-x-num')) $('align-x-num').value = 0;
            if ($('align-y')) $('align-y').value = 0;
            if ($('align-y-num')) $('align-y-num').value = 0;

            updateCrossfade();
            updateRefTransform(null);
            initAlignHandles();
            loadSeparationBase();

            logPreview('✅ Referencia cargada: ' + img.naturalWidth + '×' + img.naturalHeight + 'px', 'success');
        };
        img.onerror = function() {
            logPreview('❌ Error cargando imagen de referencia', 'error');
            alert('No se pudo cargar la imagen.');
        };
        img.src = dataUrl;
        refImageData = dataUrl;
    }

    function clearRef() {
        refImageData = null;
        if ($('ref-drop')) $('ref-drop').style.display = 'block';
        if ($('ref-canvas-wrap')) $('ref-canvas-wrap').style.display = 'none';
        if ($('crossfade-ctrl')) $('crossfade-ctrl').style.display = 'none';
        if ($('alignment-ctrl')) $('alignment-ctrl').style.display = 'none';
        if ($('btn-clear-ref')) $('btn-clear-ref').style.display = 'none';
        if ($('no-ref-msg')) $('no-ref-msg').style.display = 'block';
        if ($('analyze-btn')) $('analyze-btn').disabled = true;
        if ($('diff-results')) $('diff-results').innerHTML = '';
        if ($('align-base-img')) $('align-base-img').src = '';
        if ($('ref-preview-img')) $('ref-preview-img').style.transform = '';
        destroyAlignHandles();
    }

    // === ANALYSIS ===
    async function runAnalysis() {
        if (!refImageData || !lastJobName) {
            alert('Se necesita un trabajo procesado y una imagen de referencia');
            return;
        }
        if (isAnalyzing) return;
        isAnalyzing = true;

        var btn = $('analyze-btn');
        if (btn) {
            btn.disabled = true;
            btn.textContent = '⏳ Analizando...';
        }

        var alignVals = getAlignValues();
        var baseImg = $('align-base-img');
        var displayRatio = (baseImg && baseImg.clientWidth > 0 && baseImg.naturalWidth > 0)
            ? baseImg.naturalWidth / baseImg.clientWidth : 1;

        try {
            var resp = await fetch('/api/analyze_detailed', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    job_name: lastJobName,
                    reference: refImageData,
                    align_scale: alignVals.scale,
                    align_x: Math.round(alignVals.x * displayRatio),
                    align_y: Math.round(alignVals.y * displayRatio),
                    remove_ref_background: $('remove-ref-bg') ? $('remove-ref-bg').checked : true,
                    edge_tolerance_px: $('edge-tolerance') ? parseInt($('edge-tolerance').value, 10) : 3,
                    density_mode: $('density-mode-select') ? $('density-mode-select').value : 'auto',
                    reinforcement_keywords: $('reinforcement-keywords') ? $('reinforcement-keywords').value : ''
                })
            });
            var data = await resp.json();

            if (data.error) throw new Error(data.error);

            var diffImg = $('diff-preview-img');
            if (diffImg) {
                diffImg.src = data.diff_map;
                diffImg.style.opacity = 0.5;
            }
            if ($('diff-opacity')) $('diff-opacity').value = 50;
            if ($('diff-pct-lbl')) $('diff-pct-lbl').textContent = '50%';

            renderFindings(data);
            logPreview('✅ Análisis completado. Score: ' + data.score + '%', data.score < 30 ? 'success' : 'warn');
        } catch (err) {
            logPreview('❌ Error en análisis: ' + err.message, 'error');
            alert('Error en análisis: ' + err.message);
        } finally {
            isAnalyzing = false;
            if (btn) {
                btn.disabled = false;
                btn.textContent = 'Analizar diferencias';
            }
        }
    }

    function renderFindings(data) {
        var container = $('diff-results');
        if (!container) return;

        var scoreColor = data.score < 15 ? 'var(--accent-success)' :
                        data.score < 30 ? 'var(--accent-warning)' : 'var(--accent-error)';
        var scoreClass = data.score < 15 ? 'good' : data.score < 30 ? 'warn' : 'bad';

        var html = '';
        if (data.diff_map) {
            html += '<div style="margin-bottom: 16px; text-align: center; border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 8px; background: var(--bg-deep);">' +
                '<img src="' + data.diff_map + '" style="max-width: 100%; border-radius: var(--radius-sm); cursor: zoom-in;" onclick="PreviewModule.openFullscreen(this.src)" alt="Mapa de diferencias">' +
                '<div style="display:flex; justify-content:center; gap:14px; margin-top:8px; font-size: 0.68rem; color: var(--text-muted); font-family: var(--font-mono); flex-wrap: wrap;">' +
                    '<span><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:rgb(0,200,100);margin-right:4px;"></span>Coincide</span>' +
                    '<span><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:rgb(220,60,60);margin-right:4px;"></span>Falta (está en la referencia, no en la separación)</span>' +
                    '<span><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:rgb(40,120,255);margin-right:4px;"></span>De más (está en la separación, no en la referencia)</span>' +
                '</div>' +
            '</div>';
        }

        html += '<div class="score-card">' +
            '<div class="score-value ' + scoreClass + '">' + data.score + '%</div>' +
            '<div class="score-label">Diferencia promedio</div>' +
            '<div class="score-meta">' + (data.metrics?.separation_count || separationImages.length) + ' separaciones analizadas</div>' +
        '</div>';

        html += data.findings.map(function(f) {
            var barColor = f.status === 'ok' ? 'var(--accent-success)' :
                          f.status === 'warn' ? 'var(--accent-warning)' : 'var(--accent-error)';
            var statusText = f.status === 'ok' ? 'OK' : f.status === 'warn' ? 'REVISAR' : 'ERROR';
            var primaryText = f.human || f.msg;
            var hasTechnicalDetail = f.human && f.msg && f.human !== f.msg;
            return '<div class="diff-card">' +
                '<div class="diff-header">' +
                    '<span class="diff-title">' + f.title + '</span>' +
                    '<span class="diff-badge ' + f.status + '">' + statusText + '</span>' +
                '</div>' +
                '<div class="diff-bar-wrap">' +
                    '<div class="diff-bar" style="width:' + f.pct + '%;background:' + barColor + '"></div>' +
                '</div>' +
                '<div class="diff-msg">' + primaryText + '</div>' +
                (hasTechnicalDetail ? '<details style="margin-top:4px;">' +
                    '<summary style="font-size:0.62rem; color:var(--text-dim); cursor:pointer; font-family:var(--font-mono);">Detalles técnicos</summary>' +
                    '<div style="font-size:0.65rem; color:var(--text-muted); font-family:var(--font-mono); margin-top:4px; padding-left:8px; border-left:2px solid var(--border-subtle);">' + f.msg + '</div>' +
                '</details>' : '') +
            '</div>';
        }).join('');

        container.innerHTML = html;
    }

    // === ASE LIBRARY MANAGEMENT ===

    function initAseUI() {
        // Los botones y la lógica ya están en index.html
        // Solo nos aseguramos de que PreviewModule pueda recargar separaciones
        // cuando la biblioteca cambie

        // Escuchar cambios de biblioteca para refrescar colores
        window.addEventListener('library:changed', function(e) {
            console.log('[Preview] Biblioteca cambiada, recargando separaciones...');
            if (lastJobName) {
                loadSeparationsPreview();
            }
        });
    }

    // === UTILITIES ===
    function hexToRgb(hex) {
        var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : { r: 0, g: 0, b: 0 };
    }

    function logPreview(msg, type) {
        var prefix = type === 'error' ? '❌' : type === 'warn' ? '⚠️' : type === 'success' ? '✅' : '→';
        console.log('[Preview] ' + prefix + ' ' + msg);
    }

    // === PUBLIC API ===
    return {
        init: init,
        setViewMode: setViewMode,
        setCompositeMode: setCompositeMode,
        openColorPicker: openColorPicker,
        updateSepColor: updateSepColor,
        toggleLayer: toggleLayer,
        changeOpacity: changeOpacity,
        openFullscreen: openFullscreen,
        toggleColorize: toggleColorize,
        loadSeparationsPreview: loadSeparationsPreview,
        renderComposite: renderComposite,
        renderLayersList: renderLayersList,
        renderPreviewByMode: renderPreviewByMode
    };
})();

// Auto-init when DOM ready
document.addEventListener('DOMContentLoaded', PreviewModule.init);