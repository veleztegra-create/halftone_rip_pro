"""
Display Color Resolver
========================

Punto de sustitución (Beta Polish, Tarea 3.2): app.py llama a
`resolve_display_color(name)` y nunca a la lógica de detección de color en
sí. Cuando exista un Knowledge Interpreter real en el backend (v1.1), solo
cambia el CUERPO de esta función — nadie más en el proyecto necesita tocarse.

Reemplaza a `get_color_for_separation()` (antes vivía inline en app.py). El
comportamiento para nombres SIN modificador es idéntico al original —
verificado en test_color_name_resolver.py, no asumido.

Lo nuevo: nombres CON modificador ("azul oscuro", "verde muy claro") ya no
necesitan una entrada propia en un diccionario. Se resuelven como
`color_base + transformación de luminosidad en HSL`, según la tabla
MODIFIERS de abajo. Esto es una elección deliberada frente a la alternativa
de ir agregando `if "azul oscuro"` uno por uno: esa alternativa escala mal
(180 ifs en unas semanas, según la estimación de la discusión original).

IMPORTANTE — qué es y qué NO es este color:
Este es un color de VISUALIZACIÓN (para que el usuario distinga placas en
pantalla), no un valor Pantone ni una referencia de producción. No tiene que
ser exacto — tiene que ayudar a diferenciar. Esa es la razón por la que
ajustar luminosidad en HSL es aceptable acá aunque no sea colorimétricamente
preciso: el objetivo no es precisión, es legibilidad visual.
"""

import hashlib
import colorsys


# --- Colores con identidad propia (NO se tratan como modificador + base) ---
# Un "Navy" no es "Blue oscuro" en la industria textil — es un tono con
# nombre propio. Estos se resuelven ANTES de intentar separar
# modificador + color base, y ganan sobre cualquier detección de modificador.
NAMED_IDENTITY_COLORS = {
    'navy': (0, 0, 128),
    'royal blue': (65, 105, 225),
    'royal': (65, 105, 225),
    'kelly green': (76, 187, 23),
    'forest green': (34, 139, 34),
    'burgundy': (128, 0, 32),
    'maroon': (128, 0, 0),
}

# --- Colores base (idéntico a color_map del código anterior, sin cambios) ---
BASE_COLORS = {
    'rojo': (220, 20, 60), 'red': (220, 20, 60),
    'azul': (30, 144, 255), 'blue': (30, 144, 255),
    'verde': (34, 139, 34), 'green': (34, 139, 34),
    'amarillo': (255, 215, 0), 'yellow': (255, 215, 0),
    'naranja': (255, 140, 0), 'orange': (255, 140, 0),
    'morado': (128, 0, 128), 'purple': (128, 0, 128),
    'rosa': (255, 105, 180), 'pink': (255, 105, 180),
    'gris': (128, 128, 128), 'gray': (128, 128, 128), 'grey': (128, 128, 128),
    'blanco': (255, 255, 255), 'white': (255, 255, 255),
    'negro': (0, 0, 0), 'black': (0, 0, 0),
    'cafe': (139, 69, 19), 'brown': (139, 69, 19), 'marrón': (139, 69, 19),
    'turquesa': (64, 224, 208), 'teal': (64, 224, 208),
    'violeta': (238, 130, 238), 'violet': (238, 130, 238),
    'dorado': (255, 215, 0), 'gold': (255, 215, 0),
    'plateado': (192, 192, 192), 'silver': (192, 192, 192),
    'bronze': (205, 127, 50), 'bronce': (205, 127, 50),
    'cobre': (184, 115, 51), 'copper': (184, 115, 51),
}

CMYK_COLORS = {
    'Cyan': (0, 180, 216),
    'Magenta': (230, 58, 110),
    'Yellow': (245, 200, 0),
    'Black': (26, 26, 46),
}

# --- Tabla de modificadores: ajuste de Lightness (HSL), en puntos porcentuales ---
# Positivo = más claro, negativo = más oscuro. Todos los valores se derivan
# de LIGHTNESS_STEP en vez de ser números sueltos: si GraphXSource reporta
# que "todos los claros se sienten demasiado claros", se ajusta UN número acá
# y el sistema completo conserva las relaciones entre modificadores (deep
# sigue siendo más intenso que dark, pale más que light, etc.), en vez de
# tener que recalibrar cada entrada por separado.
LIGHTNESS_STEP = 20        # unidad base: lo que mueve "light"/"dark"
LIGHTNESS_STEP_DEEP = LIGHTNESS_STEP + 10   # "deep"/"pale" son un paso más intensos
LIGHTNESS_STEP_SUBTLE = LIGHTNESS_STEP - 10  # "vibrant" es un ajuste más sutil
LIGHTNESS_STEP_BRIGHT = LIGHTNESS_STEP - 5   # "bright" entre subtle y el step base

MODIFIERS = {
    'light':     +LIGHTNESS_STEP,
    'claro':     +LIGHTNESS_STEP,
    'pale':      +LIGHTNESS_STEP_DEEP,
    'palido':    +LIGHTNESS_STEP_DEEP,
    'pálido':    +LIGHTNESS_STEP_DEEP,
    'dark':      -LIGHTNESS_STEP,
    'oscuro':    -LIGHTNESS_STEP,
    'deep':      -LIGHTNESS_STEP_DEEP,
    'profundo':  -LIGHTNESS_STEP_DEEP,
    'vibrant':   +LIGHTNESS_STEP_SUBTLE,
    'vibrante':  +LIGHTNESS_STEP_SUBTLE,
    'bright':    +LIGHTNESS_STEP_BRIGHT,
    'brillante': +LIGHTNESS_STEP_BRIGHT,
}

# "Muy" / "very" intensifica el modificador que sigue (mismo espíritu que
# MODIFIER_KEYWORDS del Knowledge Engine JS: "muy claro" != "claro").
INTENSIFIERS = {'muy', 'very'}
INTENSIFIER_MULTIPLIER = 1.5


def _adjust_lightness(rgb, delta_pct):
    """Ajusta la Lightness de un color RGB en HSL, preservando Hue y
    Saturation. delta_pct en puntos porcentuales de Lightness (-100..100),
    clamp a [0, 100].

    NOTA PARA V1.1 (no implementado a propósito todavía): colores muy
    oscurecidos pueden percibirse "sin vida" porque pierden Saturation
    perceptual aunque el valor S en HSL no cambie. Una corrección posible
    sería sumar Saturation cuando delta_pct es muy negativo (ej. dark ->
    Lightness -20, Saturation +5). No se implementa ahora porque es
    calibración fina y todavía no hay feedback real de usuarios (GraphXSource)
    sobre si hace falta. Si se agrega, este es el único lugar a tocar."""
    r, g, b = [c / 255.0 for c in rgb]
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    l = max(0.0, min(1.0, l + (delta_pct / 100.0)))
    r2, g2, b2 = colorsys.hls_to_rgb(h, l, s)
    return (round(r2 * 255), round(g2 * 255), round(b2 * 255))


def _hash_fallback_color(name_lower):
    """Idéntico al fallback determinístico del código original: nombres no
    reconocidos obtienen un color estable (mismo nombre -> mismo color
    siempre) derivado de un hash, no aleatorio."""
    h = hashlib.md5(name_lower.encode()).hexdigest()
    hue = int(h[:8], 16) / 0xffffffff
    sat = 0.55 + (int(h[8:10], 16) / 255) * 0.25
    light = 0.45 + (int(h[10:12], 16) / 255) * 0.15
    r, g, b = colorsys.hls_to_rgb(hue, light, sat)
    return (int(r * 255), int(g * 255), int(b * 255))


def _detect_modifier(name_lower):
    """Busca un modificador conocido en el texto. Si está precedido por un
    intensificador ("muy oscuro"), multiplica su efecto. Devuelve
    (delta_pct, texto_sin_modificador) o (0, name_lower) si no hay match.
    Modificadores más largos primero, para no confundir 'claro' con parte
    de otra palabra si algún día se agregan compuestos."""
    words = name_lower.split()
    for i, word in enumerate(words):
        if word in MODIFIERS:
            delta = MODIFIERS[word]
            if i > 0 and words[i - 1] in INTENSIFIERS:
                delta *= INTENSIFIER_MULTIPLIER
                remaining = words[:i - 1] + words[i + 1:]
            else:
                remaining = words[:i] + words[i + 1:]
            return delta, ' '.join(remaining).strip()
    return 0, name_lower


def resolve_display_color(name, idx=0):
    """Punto de entrada único. Firma y comportamiento base IDÉNTICOS a
    get_color_for_separation(name, idx) del código anterior para cualquier
    nombre sin modificador reconocido (ver test_color_name_resolver.py).

    Comportamiento NUEVO: nombres con modificador ("azul oscuro", "verde
    muy claro") ya no requieren una entrada propia — se resuelven como
    color base + ajuste de Lightness en HSL.
    """
    name_lower = name.lower().strip()

    # 1. CMYK — igual que antes, primera prioridad
    for cmyk_name, color in CMYK_COLORS.items():
        if cmyk_name.lower() in name_lower:
            return color

    # 2. Colores con identidad propia — ganan sobre modificador+base
    for identity_name, color in NAMED_IDENTITY_COLORS.items():
        if identity_name in name_lower:
            return color

    # 3. Detectar modificador; si hay uno, resolver el color base restante
    #    y aplicar el ajuste de Lightness.
    delta_pct, remaining = _detect_modifier(name_lower)
    if delta_pct != 0:
        for color_name, color in BASE_COLORS.items():
            if color_name in remaining:
                return _adjust_lightness(color, delta_pct)
        # Modificador reconocido pero sin color base identificable en el
        # resto del texto: no hay nada que ajustar, cae al comportamiento
        # original (substring match / hash) sobre el name_lower completo.

    # 4. Comportamiento original: color base sin modificador
    for color_name, color in BASE_COLORS.items():
        if color_name in name_lower:
            return color

    # 5. Fallback determinístico (idéntico al original)
    return _hash_fallback_color(name_lower)
