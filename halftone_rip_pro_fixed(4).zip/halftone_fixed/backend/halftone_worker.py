"""
halftone_worker.py — Worker functions para ProcessPoolExecutor.

Este módulo NO importa Flask ni nada del servidor web.
Es seguro cargarlo en procesos hijo (fork en Linux, spawn en Windows).
Se usa solo cuando Numba NO está disponible; en ese caso, cada canal
de halftone se procesa en su propio proceso OS para evadir el GIL.
"""

import io
import base64
import numpy as np
from PIL import Image


# ─────────────────────────────────────────────────────────────────────────────
# Lógica de halftone (copia del path NumPy de app.py)
# Se duplica intencionalmente para que el worker sea auto-contenido y no
# importe app.py (evita inicializar Flask, Ghostscript, etc. en cada proceso).
# ─────────────────────────────────────────────────────────────────────────────

def _apply_halftone_numpy(channel_array, lpi, dpi, angle_deg, shape):
    """Semitono vectorizado con NumPy puro (sin Numba)."""
    h, w = channel_array.shape
    theta = float(np.deg2rad(angle_deg))
    T = dpi / lpi
    x = np.arange(w, dtype=np.float32)
    y = np.arange(h, dtype=np.float32)
    x_grid, y_grid = np.meshgrid(x, y)
    cos_t, sin_t = float(np.cos(theta)), float(np.sin(theta))
    u = x_grid * cos_t - y_grid * sin_t
    v = x_grid * sin_t + y_grid * cos_t
    u_cell = u / T
    v_cell = v / T
    u_norm = (u_cell - np.round(u_cell)) * 2.0
    v_norm = (v_cell - np.round(v_cell)) * 2.0
    if shape == 'ellipse':
        S = 3.0 * np.cos(np.pi * u_norm) + np.cos(np.pi * v_norm)
    elif shape == 'line':
        S = np.cos(np.pi * v_norm)
    elif shape == 'square':
        S = np.cos(np.pi * u_norm) * np.cos(np.pi * v_norm)
    elif shape == 'diamond':
        S = np.cos(np.pi * u_norm) + np.cos(np.pi * (u_norm + v_norm) / 2.0)
    else:  # round (default)
        S = np.cos(np.pi * u_norm) + np.cos(np.pi * v_norm)
    threshold = (S + 2.0) / 4.0
    ink_density = (255.0 - channel_array.astype(np.float32)) / 255.0
    return np.where(ink_density > threshold, 0, 255).astype(np.uint8)


def _smart_thumbnail(arr, target_max=800):
    img = Image.fromarray(arr, mode='L')
    while img.size[0] > target_max * 2 and img.size[1] > target_max * 2:
        img = img.reduce(2)
    if max(img.size) > target_max:
        ratio = target_max / max(img.size)
        new_size = (max(1, int(img.size[0] * ratio)), max(1, int(img.size[1] * ratio)))
        img = img.resize(new_size, Image.LANCZOS)
    return img


def _pil_to_base64(img, fmt='PNG'):
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()


# ─────────────────────────────────────────────────────────────────────────────
# Función top-level: requerida para ser pickleable en spawn (Windows)
# ─────────────────────────────────────────────────────────────────────────────

def process_channel_worker(args):
    """
    Procesa un canal de halftone completo en un proceso hijo.

    args: tupla (name, arr_bytes, arr_shape, lpi, dpi, angle, dot_shape, out_path)

    La placa llega como bytes planos (arr.tobytes()) + shape para evitar el
    overhead del pickle de objetos NumPy. np.frombuffer reconstituye el array
    sin copia adicional.

    Devuelve: (name, (w, h), preview_b64)
    """
    name, arr_bytes, arr_shape, lpi, dpi, angle, dot_shape, out_path = args
    # Reconstituir array sin copia (vista sobre el buffer recibido)
    arr = np.frombuffer(arr_bytes, dtype=np.uint8).reshape(arr_shape)
    halftoned = _apply_halftone_numpy(arr, lpi, dpi, angle, dot_shape)
    pil_img = Image.fromarray(halftoned, mode='L')
    pil_img.save(out_path, 'PNG', optimize=False)
    preview = _smart_thumbnail(halftoned, target_max=800)
    preview_b64 = _pil_to_base64(preview)
    return name, pil_img.size, preview_b64  # size = (w, h)
